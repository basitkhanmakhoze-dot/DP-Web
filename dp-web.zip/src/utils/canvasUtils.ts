import {
  ImageAdjustments,
  CropState,
  BgState,
  BgRemovalState,
  FrameOption,
  BadgeOption,
  TextOverlay,
  StickerOverlay,
} from '../types';

/**
 * Safely loads an image URL into an HTMLImageElement with cross-origin handling.
 */
export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(err);
    img.src = src;
  });
}

/**
 * Creates an offscreen canvas with processed cutout image (Background Removal + Eraser Mask).
 */
export function createCutoutCanvas(
  img: HTMLImageElement,
  bgRemoval: BgRemovalState,
  eraserMaskCanvas: HTMLCanvasElement | null
): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = img.width;
  canvas.height = img.height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return canvas;

  if (bgRemoval.isRemoved && bgRemoval.aiCutoutImage) {
    // Render the pixel-perfect AI transparent subject cutout
    ctx.drawImage(bgRemoval.aiCutoutImage, 0, 0, canvas.width, canvas.height);
  } else if (bgRemoval.isRemoved) {
    // Fallback Chroma / Color keying
    ctx.drawImage(img, 0, 0);
    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imgData.data;

    const keyHex = bgRemoval.keyColor.replace('#', '');
    const kr = parseInt(keyHex.substring(0, 2) || '255', 16);
    const kg = parseInt(keyHex.substring(2, 4) || '255', 16);
    const kb = parseInt(keyHex.substring(4, 6) || '255', 16);

    const tol = bgRemoval.tolerance;
    const feather = Math.max(1, bgRemoval.feather);

    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];

      const dist = Math.sqrt((r - kr) ** 2 + (g - kg) ** 2 + (b - kb) ** 2);

      if (dist < tol) {
        data[i + 3] = 0; // Completely transparent
      } else if (dist < tol + feather) {
        const alphaRatio = (dist - tol) / feather;
        data[i + 3] = Math.min(data[i + 3], Math.floor(255 * alphaRatio));
      }
    }

    ctx.putImageData(imgData, 0, 0);
  } else {
    // Normal original image
    ctx.drawImage(img, 0, 0);
  }

  // Apply manual eraser/restoration brush canvas mask if available
  if (eraserMaskCanvas) {
    ctx.globalCompositeOperation = 'destination-out';
    ctx.drawImage(eraserMaskCanvas, 0, 0, canvas.width, canvas.height);
    ctx.globalCompositeOperation = 'source-over';
  }

  return canvas;
}

/**
 * Applies color adjustments (brightness, contrast, saturation, sharpen, skin glow, etc.) to a canvas.
 * Includes edge-preserving Unsharp Masking for facial sharpness without noise or over-smoothing.
 */
export function applyAdjustments(
  sourceCanvas: HTMLCanvasElement,
  adj: ImageAdjustments
): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = sourceCanvas.width;
  canvas.height = sourceCanvas.height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return sourceCanvas;

  ctx.drawImage(sourceCanvas, 0, 0);

  // Apply CSS filter pipeline for fast rendering
  const brightnessCss = 100 + adj.brightness;
  const contrastCss = 100 + adj.contrast;
  const saturateCss = 100 + adj.saturation + adj.vibrance;

  ctx.filter = `brightness(${brightnessCss}%) contrast(${contrastCss}%) saturate(${saturateCss}%)`;
  ctx.drawImage(sourceCanvas, 0, 0);
  ctx.filter = 'none';

  // Apply skin glow / warmth if needed
  if (adj.skinGlow > 0 || adj.warmth !== 0) {
    ctx.save();
    if (adj.warmth > 0) {
      ctx.fillStyle = `rgba(255, 185, 110, ${adj.warmth / 350})`;
      ctx.globalCompositeOperation = 'overlay';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    } else if (adj.warmth < 0) {
      ctx.fillStyle = `rgba(100, 180, 255, ${Math.abs(adj.warmth) / 350})`;
      ctx.globalCompositeOperation = 'overlay';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    if (adj.skinGlow > 0) {
      ctx.fillStyle = `rgba(255, 245, 230, ${adj.skinGlow / 450})`;
      ctx.globalCompositeOperation = 'soft-light';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
    ctx.restore();
  }

  // Apply Edge-Preserving Unsharp Masking for facial detail & HD clarity
  if (adj.sharpen > 0) {
    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imgData.data;
    const w = canvas.width;
    const h = canvas.height;
    const amount = (adj.sharpen / 100) * 1.4; // Normalized sharpening factor
    const threshold = 8; // Noise reduction threshold to protect smooth skin

    const copy = new Uint8ClampedArray(data);

    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = (y * w + x) * 4;
        for (let c = 0; c < 3; c++) {
          const center = copy[i + c];
          const top = copy[((y - 1) * w + x) * 4 + c];
          const bottom = copy[((y + 1) * w + x) * 4 + c];
          const left = copy[(y * w + (x - 1)) * 4 + c];
          const right = copy[(y * w + (x + 1)) * 4 + c];

          const laplacian = 4 * center - (top + bottom + left + right);

          // Only sharpen if difference exceeds threshold (preserves smooth skin areas)
          if (Math.abs(laplacian) > threshold) {
            const sharpVal = center + laplacian * amount;
            data[i + c] = Math.min(255, Math.max(0, sharpVal));
          }
        }
      }
    }
    ctx.putImageData(imgData, 0, 0);
  }

  return canvas;
}

/**
 * Draws background layer (Solid, Gradient, Pattern, or Custom Image/Blurred original image).
 */
export function drawBackground(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  bgState: BgState,
  rawImg: HTMLImageElement | null
) {
  if (bgState.type === 'transparent') {
    // Checkerboard pattern representation
    const size = 16;
    for (let x = 0; x < width; x += size) {
      for (let y = 0; y < height; y += size) {
        ctx.fillStyle = (x / size + y / size) % 2 === 0 ? '#1f2937' : '#111827';
        ctx.fillRect(x, y, size, size);
      }
    }
    return;
  }

  // Render Custom/AI Image Background
  if ((bgState.type === 'custom' || bgState.type === 'ai' || bgState.customBgUrl) && bgState.customBgImage) {
    const bgImg = bgState.customBgImage;
    if (bgImg && bgImg.complete && bgImg.naturalWidth > 0) {
      ctx.save();
      if (bgState.blurBackground > 0) {
        ctx.filter = `blur(${bgState.blurBackground}px)`;
      }
      const imgRatio = bgImg.naturalWidth / bgImg.naturalHeight;
      const canvasRatio = width / height;
      let renderW = width;
      let renderH = height;
      let renderX = 0;
      let renderY = 0;
      if (imgRatio > canvasRatio) {
        renderW = height * imgRatio;
        renderX = (width - renderW) / 2;
      } else {
        renderH = width / imgRatio;
        renderY = (height - renderH) / 2;
      }
      ctx.drawImage(bgImg, renderX, renderY, renderW, renderH);
      ctx.restore();
      return;
    }
  }

  if (bgState.blurBackground > 0 && rawImg) {
    // Draw blurred version of original raw photo as background
    ctx.save();
    ctx.filter = `blur(${bgState.blurBackground}px) brightness(85%)`;
    ctx.drawImage(rawImg, -20, -20, width + 40, height + 40);
    ctx.restore();
    return;
  }

  if (bgState.type === 'solid') {
    ctx.fillStyle = bgState.solidColor || '#111827';
    ctx.fillRect(0, 0, width, height);
  } else if (bgState.type === 'gradient') {
    const { color1, color2, angle = 135, type = 'linear' } = bgState.gradient;
    if (type === 'linear') {
      const rad = (angle * Math.PI) / 180;
      const x1 = width / 2 - (Math.cos(rad) * width) / 2;
      const y1 = height / 2 - (Math.sin(rad) * height) / 2;
      const x2 = width / 2 + (Math.cos(rad) * width) / 2;
      const y2 = height / 2 + (Math.sin(rad) * height) / 2;

      const grad = ctx.createLinearGradient(x1, y1, x2, y2);
      grad.addColorStop(0, color1);
      grad.addColorStop(1, color2);
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
    } else {
      const grad = ctx.createRadialGradient(
        width / 2,
        height / 2,
        10,
        width / 2,
        height / 2,
        width / 1.2
      );
      grad.addColorStop(0, color1);
      grad.addColorStop(1, color2);
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
    }
  } else if (bgState.type === 'pattern') {
    ctx.fillStyle = bgState.solidColor || '#111827';
    ctx.fillRect(0, 0, width, height);

    ctx.save();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
    if (bgState.pattern === 'dots') {
      const step = 20;
      for (let x = 10; x < width; x += step) {
        for (let y = 10; y < height; y += step) {
          ctx.beginPath();
          ctx.arc(x, y, 2.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    } else if (bgState.pattern === 'grid') {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.lineWidth = 1;
      for (let x = 0; x < width; x += 30) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += 30) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }
    }
    ctx.restore();
  }
}

/**
 * Draws frame/ring around the canvas.
 */
export function drawFrame(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  frame: FrameOption
) {
  if (frame.type === 'none') return;

  const center = width / 2;
  const radius = center - frame.inset - frame.width / 2;

  ctx.save();

  if (frame.type === 'instagram-story') {
    const grad = ctx.createLinearGradient(0, height, width, 0);
    grad.addColorStop(0, '#f09433');
    grad.addColorStop(0.25, '#e6683c');
    grad.addColorStop(0.5, '#dc2743');
    grad.addColorStop(0.75, '#cc2366');
    grad.addColorStop(1, '#bc1888');

    ctx.strokeStyle = grad;
    ctx.lineWidth = frame.width;
    ctx.beginPath();
    ctx.arc(center, center, radius, 0, Math.PI * 2);
    ctx.stroke();
  } else if (frame.type === 'whatsapp-ring') {
    const grad = ctx.createLinearGradient(0, 0, width, height);
    grad.addColorStop(0, '#25D366');
    grad.addColorStop(1, '#128C7E');

    ctx.strokeStyle = grad;
    ctx.lineWidth = frame.width;
    ctx.beginPath();
    ctx.arc(center, center, radius, 0, Math.PI * 2);
    ctx.stroke();
  } else if (frame.type === 'gold-ring') {
    const grad = ctx.createLinearGradient(0, 0, width, height);
    grad.addColorStop(0, '#F59E0B');
    grad.addColorStop(0.5, '#FDE68A');
    grad.addColorStop(1, '#D97706');

    ctx.strokeStyle = grad;
    ctx.lineWidth = frame.width;
    ctx.beginPath();
    ctx.arc(center, center, radius, 0, Math.PI * 2);
    ctx.stroke();
  } else if (frame.type === 'neon-glow') {
    ctx.shadowColor = frame.color1 || '#10B981';
    ctx.shadowBlur = 15;
    ctx.strokeStyle = frame.color1 || '#10B981';
    ctx.lineWidth = frame.width;
    ctx.beginPath();
    ctx.arc(center, center, radius, 0, Math.PI * 2);
    ctx.stroke();
  } else if (frame.type === 'dashed-ring') {
    ctx.strokeStyle = frame.color1 || '#10B981';
    ctx.lineWidth = frame.width;
    ctx.setLineDash([12, 10]);
    ctx.beginPath();
    ctx.arc(center, center, radius, 0, Math.PI * 2);
    ctx.stroke();
  } else if (frame.type === 'linkedin-openwork') {
    // Draw LinkedIn 'OPEN TO WORK' green arch along bottom circle
    ctx.strokeStyle = '#0A66C2';
    ctx.lineWidth = frame.width;
    ctx.beginPath();
    ctx.arc(center, center, radius, 0, Math.PI * 2);
    ctx.stroke();

    // Curved banner background at bottom arc
    ctx.fillStyle = '#0A66C2';
    ctx.beginPath();
    ctx.arc(center, center, radius, Math.PI * 0.25, Math.PI * 0.75);
    ctx.lineWidth = frame.width * 2.2;
    ctx.stroke();

    // Text "OPEN TO WORK"
    ctx.font = `bold ${Math.round(width * 0.045)}px sans-serif`;
    ctx.fillStyle = '#FFFFFF';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    ctx.save();
    ctx.translate(center, center);
    ctx.rotate(Math.PI * 0.5);
    ctx.fillText('#OPENTOWORK', 0, radius - 2);
    ctx.restore();
  }

  ctx.restore();
}

/**
 * Draws Badge / Verification mark onto canvas.
 */
export function drawBadge(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  badge: BadgeOption
) {
  if (badge.type === 'none') return;

  const size = Math.round(width * 0.12 * badge.size);
  let x = width * 0.82;
  let y = height * 0.82;

  if (badge.position === 'bottom-center') {
    x = width * 0.5;
    y = height * 0.88;
  } else if (badge.position === 'top-right') {
    x = width * 0.82;
    y = height * 0.18;
  } else if (badge.position === 'top-left') {
    x = width * 0.18;
    y = height * 0.18;
  }

  ctx.save();

  if (badge.type === 'verified-blue') {
    // Draw Blue Verified Checkmark Circle
    ctx.beginPath();
    ctx.arc(x, y, size / 2, 0, Math.PI * 2);
    ctx.fillStyle = '#1D9BF0'; // Twitter/FB verified blue
    ctx.fill();

    // White Checkmark
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = size * 0.14;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(x - size * 0.2, y);
    ctx.lineTo(x - size * 0.05, y + size * 0.15);
    ctx.lineTo(x + size * 0.22, y - size * 0.18);
    ctx.stroke();
  } else if (badge.type === 'whatsapp-green') {
    ctx.beginPath();
    ctx.arc(x, y, size / 2, 0, Math.PI * 2);
    ctx.fillStyle = '#25D366';
    ctx.fill();

    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = size * 0.14;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(x - size * 0.2, y);
    ctx.lineTo(x - size * 0.05, y + size * 0.15);
    ctx.lineTo(x + size * 0.22, y - size * 0.18);
    ctx.stroke();
  } else if (badge.type === 'gold-star') {
    ctx.beginPath();
    ctx.arc(x, y, size / 2, 0, Math.PI * 2);
    ctx.fillStyle = '#F59E0B';
    ctx.fill();

    // Draw Star
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const angle = (i * 4 * Math.PI) / 5 - Math.PI / 2;
      const rx = x + Math.cos(angle) * (size * 0.3);
      const ry = y + Math.sin(angle) * (size * 0.3);
      if (i === 0) ctx.moveTo(rx, ry);
      else ctx.lineTo(rx, ry);
    }
    ctx.closePath();
    ctx.fill();
  } else if (badge.type === 'pro-pill' || badge.type === 'creator-pill' || badge.type === 'custom-pill') {
    const text = badge.text || 'PRO';
    ctx.font = `bold ${Math.round(size * 0.55)}px sans-serif`;
    const textWidth = ctx.measureText(text).width;
    const paddingX = size * 0.35;
    const pillW = textWidth + paddingX * 2;
    const pillH = size * 0.75;

    ctx.fillStyle = badge.bgColor || '#10B981';
    ctx.beginPath();
    ctx.roundRect(x - pillW / 2, y - pillH / 2, pillW, pillH, pillH / 2);
    ctx.fill();

    ctx.fillStyle = badge.textColor || '#FFFFFF';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, x, y);
  }

  ctx.restore();
}

/**
 * Draws custom Text overlays onto canvas.
 */
export function drawTextOverlay(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  textItem: TextOverlay
) {
  if (!textItem.text) return;

  const y = height * (textItem.positionY / 100);
  const x = width / 2;

  ctx.save();
  ctx.font = `bold ${Math.round(width * (textItem.fontSize / 1000))}px ${textItem.fontFamily}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  if (textItem.bgColor !== 'transparent') {
    const metrics = ctx.measureText(textItem.text);
    const pX = width * 0.04;
    const pY = height * 0.02;
    const boxW = metrics.width + pX * 2;
    const boxH = (textItem.fontSize * width) / 500 + pY;

    ctx.fillStyle = textItem.bgColor;
    ctx.beginPath();
    ctx.roundRect(x - boxW / 2, y - boxH / 2, boxW, boxH, 12);
    ctx.fill();
  }

  if (textItem.hasShadow) {
    ctx.shadowColor = 'rgba(0, 0, 0, 0.7)';
    ctx.shadowBlur = 10;
    ctx.shadowOffsetY = 4;
  }

  if (textItem.hasOutline) {
    ctx.strokeStyle = textItem.outlineColor || '#000000';
    ctx.lineWidth = 6;
    ctx.strokeText(textItem.text, x, y);
  }

  ctx.fillStyle = textItem.color || '#FFFFFF';
  ctx.fillText(textItem.text, x, y);

  ctx.restore();
}

/**
 * Draws Stickers onto canvas.
 */
export function drawSticker(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  sticker: StickerOverlay
) {
  const x = (sticker.x / 100) * width;
  const y = (sticker.y / 100) * height;

  ctx.save();
  ctx.translate(x, y);
  ctx.rotate((sticker.rotation * Math.PI) / 180);

  ctx.font = `${sticker.size}px sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(sticker.emojiOrUrl, 0, 0);

  ctx.restore();
}

/**
 * Main Master Render Engine: Renders full composition to target canvas.
 */
export function renderMasterDP(
  targetCanvas: HTMLCanvasElement,
  cutoutCanvas: HTMLCanvasElement,
  rawImage: HTMLImageElement,
  cropState: CropState,
  bgState: BgState,
  frame: FrameOption,
  badge: BadgeOption,
  textOverlays: TextOverlay[],
  stickers: StickerOverlay[],
  outputSize: number = 1080
) {
  targetCanvas.width = outputSize;
  targetCanvas.height = outputSize;
  const ctx = targetCanvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return;

  ctx.clearRect(0, 0, outputSize, outputSize);

  // 1. Draw Background
  drawBackground(ctx, outputSize, outputSize, bgState, rawImage);

  // 2. Draw Subject / Photo Layer with Crop, Scale, Rotate, Offset
  ctx.save();
  const center = outputSize / 2;
  ctx.translate(center + (cropState.offsetX / 100) * outputSize, center + (cropState.offsetY / 100) * outputSize);
  ctx.rotate((cropState.rotation * Math.PI) / 180);
  ctx.scale(
    (cropState.flipH ? -1 : 1) * cropState.scale,
    (cropState.flipV ? -1 : 1) * cropState.scale
  );

  // Fit image proportionally into canvas
  const imgAspect = cutoutCanvas.width / cutoutCanvas.height;
  let drawW = outputSize;
  let drawH = outputSize;
  if (imgAspect > 1) {
    drawH = outputSize / imgAspect;
  } else {
    drawW = outputSize * imgAspect;
  }

  ctx.drawImage(cutoutCanvas, -drawW / 2, -drawH / 2, drawW, drawH);
  ctx.restore();

  // 3. Draw Frame / Rings
  drawFrame(ctx, outputSize, outputSize, frame);

  // 4. Draw Badges
  drawBadge(ctx, outputSize, outputSize, badge);

  // 5. Draw Text Overlays
  textOverlays.forEach((txt) => drawTextOverlay(ctx, outputSize, outputSize, txt));

  // 6. Draw Stickers
  stickers.forEach((stk) => drawSticker(ctx, outputSize, outputSize, stk));
}

/**
 * Compresses canvas to target Blob & calculates size in KB/MB.
 */
export async function compressCanvas(
  canvas: HTMLCanvasElement,
  quality: number = 0.8,
  format: 'image/jpeg' | 'image/png' | 'image/webp' = 'image/jpeg'
): Promise<{ blob: Blob; dataUrl: string; sizeKB: number }> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (!blob) {
          reject(new Error('Failed to compress canvas'));
          return;
        }
        const dataUrl = URL.createObjectURL(blob);
        const sizeKB = Math.round(blob.size / 1024);
        resolve({ blob, dataUrl, sizeKB });
      },
      format,
      quality
    );
  });
}
