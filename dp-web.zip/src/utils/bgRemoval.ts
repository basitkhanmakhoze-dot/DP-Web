import { removeBackground } from '@imgly/background-removal';
import { loadImage } from './canvasUtils';

/**
 * Executes AI-powered background removal on an HTMLImageElement or Blob source.
 * Uses ONNX neural network segmentation with monotonic progress reporting and fallback handling.
 */
export async function removeImageBackground(
  imageInput: HTMLImageElement | string | Blob | File,
  onProgress?: (progressPct: number) => void
): Promise<HTMLImageElement> {
  let highestPct = 5;

  const updateProgress = (pct: number) => {
    const rounded = Math.min(99, Math.max(highestPct, Math.round(pct)));
    if (rounded > highestPct) {
      highestPct = rounded;
      if (onProgress) onProgress(highestPct);
    }
  };

  try {
    let source: Blob | string;

    if (imageInput instanceof HTMLImageElement) {
      // Render image onto offscreen canvas to obtain a clean PNG Blob
      const canvas = document.createElement('canvas');
      canvas.width = imageInput.naturalWidth || imageInput.width || 1080;
      canvas.height = imageInput.naturalHeight || imageInput.height || 1080;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Canvas context unavailable');
      ctx.drawImage(imageInput, 0, 0, canvas.width, canvas.height);

      const blob = await new Promise<Blob | null>((resolve) =>
        canvas.toBlob((b) => resolve(b), 'image/png')
      );
      if (!blob) throw new Error('Could not serialize image to blob');
      source = blob;
    } else {
      source = imageInput;
    }

    updateProgress(12);

    // Run Neural Network AI Background Removal model with monotonic progress
    const resultBlob = await removeBackground(source, {
      progress: (key: string, current: number, total: number) => {
        let ratio = 0;
        if (total && total > 0) {
          ratio = Math.min(1, Math.max(0, current / total));
        }

        let phaseStart = 15;
        let phaseEnd = 98;

        const lowerKey = (key || '').toLowerCase();
        if (lowerKey.includes('fetch')) {
          phaseStart = 15;
          phaseEnd = 65;
        } else if (lowerKey.includes('wasm') || lowerKey.includes('onnx')) {
          phaseStart = 65;
          phaseEnd = 80;
        } else if (lowerKey.includes('compute') || lowerKey.includes('inference')) {
          phaseStart = 80;
          phaseEnd = 98;
        }

        const calculated = phaseStart + ratio * (phaseEnd - phaseStart);
        updateProgress(calculated);
      },
      output: {
        format: 'image/png',
        quality: 1,
      },
    });

    if (onProgress) onProgress(100);

    const objectUrl = URL.createObjectURL(resultBlob);
    return await loadImage(objectUrl);
  } catch (err) {
    console.warn('Primary AI background removal model encountered an error, trying smart fallback:', err);
    
    // Fallback: Smart Edge-Preserving Contrast Cutout on Canvas
    return await smartFallbackBackgroundRemoval(imageInput, updateProgress, highestPct);
  }
}

/**
 * Smart Fallback algorithm: High-contrast subject detection and background isolation
 */
async function smartFallbackBackgroundRemoval(
  imageInput: HTMLImageElement | string | Blob | File,
  updateProgress: (pct: number) => void,
  startPct: number
): Promise<HTMLImageElement> {
  let img: HTMLImageElement;
  if (imageInput instanceof HTMLImageElement) {
    img = imageInput;
  } else if (typeof imageInput === 'string') {
    img = await loadImage(imageInput);
  } else {
    const url = URL.createObjectURL(imageInput);
    img = await loadImage(url);
  }

  updateProgress(Math.max(startPct, 60));

  const canvas = document.createElement('canvas');
  canvas.width = img.naturalWidth || img.width || 1080;
  canvas.height = img.naturalHeight || img.height || 1080;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return img;

  ctx.drawImage(img, 0, 0);
  const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imgData.data;
  const w = canvas.width;
  const h = canvas.height;

  // Sample corner pixels to estimate background color profile
  const samples = [
    [0, 0], [w - 1, 0], [0, h - 1], [w - 1, h - 1],
    [Math.floor(w / 2), 0], [0, Math.floor(h / 2)], [w - 1, Math.floor(h / 2)]
  ];

  let bgR = 0, bgG = 0, bgB = 0;
  samples.forEach(([x, y]) => {
    const idx = (y * w + x) * 4;
    bgR += data[idx];
    bgG += data[idx + 1];
    bgB += data[idx + 2];
  });
  bgR /= samples.length;
  bgG /= samples.length;
  bgB /= samples.length;

  const tolerance = 45;
  const totalPixels = data.length / 4;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    const dist = Math.sqrt((r - bgR) ** 2 + (g - bgG) ** 2 + (b - bgB) ** 2);
    if (dist < tolerance) {
      data[i + 3] = 0; // Transparent
    } else if (dist < tolerance + 15) {
      data[i + 3] = Math.floor(255 * ((dist - tolerance) / 15));
    }

    if (i % 25000 === 0) {
      const pixelIdx = i / 4;
      const pct = 60 + (pixelIdx / totalPixels) * 38;
      updateProgress(pct);
    }
  }

  ctx.putImageData(imgData, 0, 0);
  updateProgress(100);

  const dataUrl = canvas.toDataURL('image/png');
  return await loadImage(dataUrl);
}

