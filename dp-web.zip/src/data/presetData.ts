import { DPTemplate, FrameOption, BadgeOption, SampleAvatar } from '../types';

export const SAMPLE_AVATARS: SampleAvatar[] = [
  {
    id: 'sample-1',
    name: 'Alex Rivera',
    role: 'Tech Entrepreneur',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'sample-2',
    name: 'David Chen',
    role: 'Software Architect',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'sample-3',
    name: 'Sophia Patel',
    role: 'Product Designer',
    url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'sample-4',
    name: 'Marcus Johnson',
    role: 'Creative Director',
    url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'sample-5',
    name: 'Elena Rostova',
    role: 'Content Creator',
    url: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&q=80&w=800',
  },
];

export const PRESET_FRAMES: FrameOption[] = [
  { id: 'f-none', name: 'No Frame', type: 'none', color1: '#000000', width: 0, inset: 0 },
  { id: 'f-emerald-neon', name: 'Emerald Neon', type: 'neon-glow', color1: '#10B981', color2: '#059669', width: 8, inset: 4 },
  { id: 'f-ig-story', name: 'Instagram Story Ring', type: 'instagram-story', color1: '#f09433', color2: '#bc1888', width: 10, inset: 6 },
  { id: 'f-whatsapp-green', name: 'WhatsApp Border', type: 'whatsapp-ring', color1: '#25D366', color2: '#128C7E', width: 8, inset: 4 },
  { id: 'f-gold-luxury', name: 'Gold Luxury', type: 'gold-ring', color1: '#F59E0B', color2: '#D97706', width: 10, inset: 6 },
  { id: 'f-dashed-circle', name: 'Dashed Creative', type: 'dashed-ring', color1: '#10B981', width: 6, inset: 8 },
  { id: 'f-double-ring', name: 'Double Ring', type: 'double-ring', color1: '#06B6D4', color2: '#3B82F6', width: 8, inset: 6 },
  { id: 'f-linkedin-work', name: 'LinkedIn Open to Work', type: 'linkedin-openwork', color1: '#0A66C2', width: 14, inset: 0 },
];

export const PRESET_BADGES: BadgeOption[] = [
  { id: 'b-none', name: 'No Badge', type: 'none', position: 'bottom-right', size: 1 },
  { id: 'b-verified-blue', name: 'Blue Verified Tick', type: 'verified-blue', position: 'bottom-right', size: 1.1 },
  { id: 'b-whatsapp-green', name: 'WhatsApp Official Tick', type: 'whatsapp-green', position: 'bottom-right', size: 1.1 },
  { id: 'b-gold-star', name: 'Gold VIP Star', type: 'gold-star', position: 'bottom-right', size: 1.1 },
  { id: 'b-open-work', name: 'Open To Work', type: 'open-to-work', position: 'bottom-center', size: 1.0, text: 'OPEN TO WORK' },
  { id: 'b-pro-pill', name: 'PRO Badge', type: 'pro-pill', position: 'bottom-right', size: 1.0, text: 'PRO', bgColor: '#10B981', textColor: '#FFFFFF' },
  { id: 'b-creator-pill', name: 'CREATOR', type: 'creator-pill', position: 'bottom-right', size: 1.0, text: 'CREATOR', bgColor: '#8B5CF6', textColor: '#FFFFFF' },
  { id: 'b-founder-pill', name: 'FOUNDER', type: 'custom-pill', position: 'bottom-right', size: 1.0, text: 'FOUNDER', bgColor: '#059669', textColor: '#FFFFFF' },
];

export const PRESET_GRADIENTS = [
  { name: 'Emerald Deep', color1: '#059669', color2: '#111827', angle: 135 },
  { name: 'Material Mint', color1: '#10B981', color2: '#065F46', angle: 90 },
  { name: 'Dark Obsidian', color1: '#1F2937', color2: '#030712', angle: 180 },
  { name: 'Cyber Teal', color1: '#0D9488', color2: '#1E1B4B', angle: 135 },
  { name: 'Sunset Glow', color1: '#F59E0B', color2: '#DC2626', angle: 120 },
  { name: 'Instagram Vibe', color1: '#833AB4', color2: '#F77737', angle: 45 },
  { name: 'Royal Purple', color1: '#6D28D9', color2: '#1E1B4B', angle: 135 },
  { name: 'Studio Neutral', color1: '#E5E7EB', color2: '#9CA3AF', angle: 180 },
  { name: 'Golden Hour', color1: '#FBBF24', color2: '#B45309', angle: 135 },
  { name: 'Oceanic Blue', color1: '#0284C7', color2: '#0F172A', angle: 135 },
];

export const PRESET_SOLID_COLORS = [
  '#000000', '#111827', '#1F2937', '#374151', '#4B5563', '#6B7280',
  '#FFFFFF', '#F9FAFB', '#F3F4F6', '#E5E7EB', '#D1D5DB',
  '#059669', '#10B981', '#34D399', '#065F46', '#022C22',
  '#0284C7', '#2563EB', '#4F46E5', '#7C3AED', '#C026D3',
  '#E11D48', '#DC2626', '#EA580C', '#D97706', '#CA8A04',
];

export const PRESET_TEMPLATES: DPTemplate[] = [
  {
    id: 't-tech-founder',
    name: 'Tech Founder Pro',
    category: 'Tech',
    bgState: {
      type: 'gradient',
      gradient: { color1: '#059669', color2: '#111827', angle: 135, type: 'linear' },
      blurBackground: 0,
    },
    adjustments: { brightness: 5, contrast: 15, sharpen: 20, skinGlow: 10 },
    frame: { id: 'f-emerald-neon', name: 'Emerald Neon', type: 'neon-glow', color1: '#10B981', color2: '#059669', width: 8, inset: 4 },
    badge: { id: 'b-verified-blue', name: 'Blue Verified', type: 'verified-blue', position: 'bottom-right', size: 1.1 },
  },
  {
    id: 't-whatsapp-biz',
    name: 'WhatsApp Business',
    category: 'Social',
    bgState: {
      type: 'solid',
      solidColor: '#075E54',
    },
    adjustments: { brightness: 8, contrast: 10, sharpen: 15 },
    frame: { id: 'f-whatsapp-green', name: 'WhatsApp Ring', type: 'whatsapp-ring', color1: '#25D366', color2: '#128C7E', width: 8, inset: 4 },
    badge: { id: 'b-whatsapp-green', name: 'WhatsApp Tick', type: 'whatsapp-green', position: 'bottom-right', size: 1.1 },
  },
  {
    id: 't-ig-influencer',
    name: 'Instagram Creator',
    category: 'Social',
    bgState: {
      type: 'gradient',
      gradient: { color1: '#833AB4', color2: '#F77737', angle: 45, type: 'linear' },
    },
    adjustments: { brightness: 10, contrast: 12, skinGlow: 25, saturation: 10 },
    frame: { id: 'f-ig-story', name: 'IG Story Ring', type: 'instagram-story', color1: '#f09433', color2: '#bc1888', width: 10, inset: 6 },
    badge: { id: 'b-creator-pill', name: 'CREATOR', type: 'creator-pill', position: 'bottom-right', size: 1.0, text: 'CREATOR', bgColor: '#8B5CF6', textColor: '#FFFFFF' },
  },
  {
    id: 't-linkedin-pro',
    name: 'LinkedIn Open to Work',
    category: 'Corporate',
    bgState: {
      type: 'gradient',
      gradient: { color1: '#1F2937', color2: '#111827', angle: 180, type: 'linear' },
    },
    adjustments: { brightness: 5, contrast: 15, sharpen: 25 },
    frame: { id: 'f-linkedin-work', name: 'LinkedIn Ring', type: 'linkedin-openwork', color1: '#0A66C2', width: 14, inset: 0 },
    badge: { id: 'b-open-work', name: 'Open To Work', type: 'open-to-work', position: 'bottom-center', size: 1.0, text: 'OPEN TO WORK' },
  },
  {
    id: 't-luxury-gold',
    name: 'Luxury Executive',
    category: 'Luxury',
    bgState: {
      type: 'gradient',
      gradient: { color1: '#1F2937', color2: '#030712', angle: 135, type: 'linear' },
    },
    adjustments: { brightness: 5, contrast: 20, sharpen: 30, skinGlow: 15 },
    frame: { id: 'f-gold-luxury', name: 'Gold Luxury', type: 'gold-ring', color1: '#F59E0B', color2: '#D97706', width: 10, inset: 6 },
    badge: { id: 'b-gold-star', name: 'Gold Star', type: 'gold-star', position: 'bottom-right', size: 1.1 },
  },
  {
    id: 't-aesthetic-minimal',
    name: 'Aesthetic Studio',
    category: 'Aesthetic',
    bgState: {
      type: 'solid',
      solidColor: '#F3F4F6',
    },
    adjustments: { brightness: 12, contrast: 5, warmth: 10, skinGlow: 20 },
    frame: { id: 'f-dashed-circle', name: 'Dashed', type: 'dashed-ring', color1: '#10B981', width: 6, inset: 8 },
    badge: { id: 'b-verified-blue', name: 'Verified', type: 'verified-blue', position: 'bottom-right', size: 1.0 },
  },
];

export const FONT_LIST = [
  { name: 'Sans-Serif Modern', value: 'Inter, system-ui, sans-serif' },
  { name: 'Bold Display', value: '"Plus Jakarta Sans", sans-serif' },
  { name: 'Elegant Serif', value: 'Playfair Display, Georgia, serif' },
  { name: 'Cyber Monospace', value: 'ui-monospace, SFMono-Regular, monospace' },
  { name: 'Impact Heavy', value: 'Impact, Haettenschweiler, sans-serif' },
];

export const STICKER_PACK = [
  '🔥', '✨', '⚡', '👑', '💎', '🚀', '⭐', '💯', '📸', '🎧',
  '💻', '🎓', '🏆', '🎯', '❤️', '💼', '🌿', '📍', '✅', '💥',
];

export interface HdBgPreset {
  id: string;
  name: string;
  category: string;
  emoji: string;
  prompt: string;
  url: string;
}

export const AI_BG_SUGGESTIONS = [
  { label: 'Mountains', emoji: '🏔️', prompt: 'Majestic snow-capped mountain peaks at golden hour sunset' },
  { label: 'Luxury Office', emoji: '🏢', prompt: 'Modern high-rise penthouse executive office interior with glass city view' },
  { label: 'Cricket Stadium', emoji: '🏏', prompt: 'Packed illuminated cricket stadium with floodlights under night sky' },
  { label: 'Pakistan Flag', emoji: '🇵🇰', prompt: 'Aesthetic deep emerald green and white national flag texture with crescent' },
  { label: 'Islamic Mosque', emoji: '🕌', prompt: 'Grand illuminated Islamic architecture mosque with minarets at twilight' },
  { label: 'Blue Studio', emoji: '🟦', prompt: 'Sleek royal blue studio portrait wall backdrop with soft rim lighting' },
  { label: 'Nature', emoji: '🌿', prompt: 'Sunlit green pine forest landscape with soft ray lights and bokeh' },
  { label: 'Wedding Stage', emoji: '💒', prompt: 'Royal luxury wedding stage with white roses, golden lights and chandelier' },
  { label: 'Birthday', emoji: '🎂', prompt: 'Festive birthday backdrop with metallic gold balloons and party lights' },
  { label: 'Galaxy', emoji: '🌌', prompt: 'Deep space galaxy nebula with shining stars and purple stardust' },
  { label: 'Beach', emoji: '🏖️', prompt: 'Serene ocean beach with turquoise water, palm trees and golden sun' },
  { label: 'City Sunset', emoji: '🌃', prompt: 'Dramatic city skyline skyscrapers view at twilight with orange clouds' },
  { label: 'Snow Mountain', emoji: '❄️', prompt: 'Breathtaking snowy mountain peak summit with crisp blue sky' },
  { label: 'Rainy Mood', emoji: '🌧️', prompt: 'Cinematic rainy city street backdrop at night with blurred neon lights' },
  { label: 'Sports Car', emoji: '🏎️', prompt: 'High-end luxury red sports car in modern architectural showroom' },
  { label: 'Airport Lounge', emoji: '✈️', prompt: 'Modern international airport lounge with large glass window runway view' },
  { label: 'Black Theme', emoji: '🖤', prompt: 'Ultra-sleek dark black textured obsidian stone background with vignette' },
  { label: 'White Studio', emoji: '⬜', prompt: 'Clean bright minimalist white studio infinity backdrop with soft shadow' },
  { label: 'Cyberpunk Neon', emoji: '🏙️', prompt: 'Futuristic cyberpunk neon street with glowing magenta and cyan lights' },
  { label: 'Bokeh Lights', emoji: '💡', prompt: 'Warm golden festive fairy lights bokeh blur backdrop' },
  { label: 'Cozy Studio', emoji: '☕', prompt: 'Cozy aesthetic warm coffee shop wooden interior with warm pendant lights' },
];

export const PRESET_HD_BACKGROUNDS: HdBgPreset[] = [
  {
    id: 'bg-mountains',
    name: 'Sunset Mountains',
    category: 'Nature',
    emoji: '🏔️',
    prompt: 'Majestic snow-capped mountain peaks at golden hour sunset with vibrant orange clouds',
    url: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-luxury-office',
    name: 'Luxury Penthouse Office',
    category: 'Professional',
    emoji: '🏢',
    prompt: 'Modern high-rise penthouse executive office interior with glass city view',
    url: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-cricket-stadium',
    name: 'Floodlit Cricket Stadium',
    category: 'Sports',
    emoji: '🏏',
    prompt: 'Packed illuminated sports stadium with green field floodlights at night',
    url: 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-pakistan-flag',
    name: 'Pakistan Emerald Flag',
    category: 'National',
    emoji: '🇵🇰',
    prompt: 'Aesthetic deep emerald green and white national flag texture with crescent',
    url: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-islamic-mosque',
    name: 'Grand Islamic Mosque',
    category: 'Spiritual',
    emoji: '🕌',
    prompt: 'Grand illuminated Islamic architecture mosque domes and minarets under twilight sky',
    url: 'https://images.unsplash.com/photo-1542810634-71277d95dcbb?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-blue-studio',
    name: 'Royal Blue Studio',
    category: 'Studio',
    emoji: '🟦',
    prompt: 'Minimalist royal blue studio portrait wall backdrop with soft rim lighting',
    url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-nature-forest',
    name: 'Sunlit Forest',
    category: 'Nature',
    emoji: '🌿',
    prompt: 'Sunlit green pine forest landscape with soft ray lights and bokeh effect',
    url: 'https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-wedding-stage',
    name: 'Royal Wedding Stage',
    category: 'Events',
    emoji: '💒',
    prompt: 'Luxury royal wedding stage with white roses, golden lights and chandelier decor',
    url: 'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-birthday-party',
    name: 'Golden Birthday Gala',
    category: 'Events',
    emoji: '🎂',
    prompt: 'Festive birthday backdrop with metallic gold balloons, sparkle bokeh and party lights',
    url: 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-galaxy-nebula',
    name: 'Cosmic Deep Galaxy',
    category: 'Space',
    emoji: '🌌',
    prompt: 'Deep space cosmic galaxy nebula with glowing stars and purple blue stardust',
    url: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-tropical-beach',
    name: 'Turquoise Beach',
    category: 'Nature',
    emoji: '🏖️',
    prompt: 'Serene tropical ocean beach shore with turquoise water, palm trees and golden sun',
    url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-city-skyline',
    name: 'City Sunset Skyline',
    category: 'Urban',
    emoji: '🌃',
    prompt: 'Dramatic city skyline skyscrapers view at twilight with orange and purple reflections',
    url: 'https://images.unsplash.com/photo-1477959858617-67f30ac4ce78?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-snow-summit',
    name: 'Alpine Snow Summit',
    category: 'Nature',
    emoji: '❄️',
    prompt: 'Breathtaking snowy mountain peak under clear blue sky with crisp sunlight',
    url: 'https://images.unsplash.com/photo-1486870591958-9b9d0d1dda99?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-rainy-mood',
    name: 'Cinematic Rainy Street',
    category: 'Mood',
    emoji: '🌧️',
    prompt: 'Cinematic rainy city street backdrop at night with blurred neon reflections',
    url: 'https://images.unsplash.com/photo-1519692933481-e162a57d6721?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-sports-car',
    name: 'Luxury Sports Car',
    category: 'Lifestyle',
    emoji: '🏎️',
    prompt: 'High-end luxury red sports car in modern architectural garage showroom',
    url: 'https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-airport-lounge',
    name: 'Airport VIP Lounge',
    category: 'Lifestyle',
    emoji: '✈️',
    prompt: 'Modern international airport terminal lounge with large glass window runway view',
    url: 'https://images.unsplash.com/photo-1542296332-2e4473faf563?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-black-obsidian',
    name: 'Dark Obsidian Black',
    category: 'Minimal',
    emoji: '🖤',
    prompt: 'Ultra-sleek dark black textured obsidian stone background with subtle vignette',
    url: 'https://images.unsplash.com/photo-1550684848-86a5d8727436?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-white-infinity',
    name: 'Infinity White Studio',
    category: 'Studio',
    emoji: '⬜',
    prompt: 'Clean bright minimalist white studio backdrop with soft floor shadow',
    url: 'https://images.unsplash.com/photo-1590381105924-c72589b9ef3f?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-cyberpunk-neon',
    name: 'Cyberpunk Neon City',
    category: 'Urban',
    emoji: '🏙️',
    prompt: 'Futuristic cyberpunk neon street at night with glowing magenta and cyan lights',
    url: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-bokeh-lights',
    name: 'Golden Bokeh Lights',
    category: 'Abstract',
    emoji: '💡',
    prompt: 'Warm golden festive fairy lights bokeh blur backdrop',
    url: 'https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'bg-cozy-loft',
    name: 'Cozy Loft Studio',
    category: 'Lifestyle',
    emoji: '☕',
    prompt: 'Cozy aesthetic warm coffee shop wooden interior with warm pendant lights',
    url: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&q=80&w=1200',
  },
];
