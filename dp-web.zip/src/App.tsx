import React, { useState, useRef, useEffect } from 'react';
import { Header } from './components/Header';
import { SplashScreen } from './components/SplashScreen';
import { PhotoEditor } from './components/PhotoEditor';

// Tools
import { TemplateSelector } from './components/tools/TemplateSelector';
import { BgRemoverTool } from './components/tools/BgRemoverTool';
import { EnhancerTool } from './components/tools/EnhancerTool';
import { CropTool } from './components/tools/CropTool';
import { BgChangerTool } from './components/tools/BgChangerTool';
import { FramesTool } from './components/tools/FramesTool';
import { TextBadgeTool } from './components/tools/TextBadgeTool';
import { StickersTool } from './components/tools/StickersTool';
import { BlurTool } from './components/tools/BlurTool';
import { CompressorTool } from './components/tools/CompressorTool';

// Modals
import { ExportShareModal } from './components/tools/ExportShareModal';
import { SampleAvatarsModal } from './components/modals/SampleAvatarsModal';
import { GeminiAdviceModal } from './components/modals/GeminiAdviceModal';
import { AiAssistantDrawer, AssistantAction } from './components/modals/AiAssistantDrawer';

import {
  CropState,
  BgState,
  BgRemovalState,
  FrameOption,
  BadgeOption,
  TextOverlay,
  StickerOverlay,
  ImageAdjustments,
  SocialPlatformType,
  DPTemplate,
  SampleAvatar,
} from './types';
import { PRESET_TEMPLATES, PRESET_FRAMES, PRESET_BADGES, SAMPLE_AVATARS, HdBgPreset } from './data/presetData';
import { loadImage } from './utils/canvasUtils';
import { removeImageBackground } from './utils/bgRemoval';

import {
  Sparkles,
  Scissors,
  Sliders,
  Crop,
  Palette,
  Circle,
  BadgeCheck,
  Smile,
  Droplet,
  HardDrive,
} from 'lucide-react';

export default function App() {
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [rawImage, setRawImage] = useState<HTMLImageElement | null>(null);

  // Active Tool Tab
  const [activeTab, setActiveTab] = useState<
    | 'templates'
    | 'bgremover'
    | 'enhancer'
    | 'crop'
    | 'bgchanger'
    | 'frames'
    | 'badges'
    | 'stickers'
    | 'blur'
    | 'compressor'
  >('templates');

  // Modals state
  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);
  const [isSampleOpen, setIsSampleOpen] = useState<boolean>(false);
  const [isGeminiOpen, setIsGeminiOpen] = useState<boolean>(false);
  const [isAssistantOpen, setIsAssistantOpen] = useState<boolean>(false);

  const handlePerformAssistantAction = (action: AssistantAction) => {
    if (!action) return;

    // 1. Switch Tab
    if (action.actionType === 'switch_tab' || action.tab) {
      const targetTab = action.tab as any;
      if (['templates', 'bgremover', 'enhancer', 'crop', 'bgchanger', 'frames', 'badges', 'stickers', 'blur', 'compressor'].includes(targetTab)) {
        setActiveTab(targetTab);
      }
    }

    // 2. Apply Template
    if (action.actionType === 'apply_template' && action.payload?.templateId) {
      const template = PRESET_TEMPLATES.find((t) => t.id === action.payload.templateId);
      if (template) {
        handleSelectTemplate(template);
      }
    }

    // 3. Apply Preset
    if (action.actionType === 'apply_preset' && action.payload?.preset) {
      const preset = action.payload.preset;
      setActiveTab('enhancer');
      if (preset === 'auto-hd') {
        setAdjustments((prev) => ({
          ...prev,
          brightness: 8,
          contrast: 15,
          saturation: 10,
          sharpen: 30,
          vibrance: 12,
          warmth: 0,
          skinGlow: 15,
        }));
      }
    }

    // 4. Select Frame
    if (action.actionType === 'select_frame' && action.payload?.frameId) {
      const selectedFrame = PRESET_FRAMES.find((f) => f.id === action.payload.frameId);
      if (selectedFrame) {
        setFrame(selectedFrame);
        setActiveTab('frames');
      }
    }

    // 5. Select Badge
    if (action.actionType === 'select_badge' && action.payload?.badgeId) {
      const selectedBadge = PRESET_BADGES.find((b) => b.id === action.payload.badgeId);
      if (selectedBadge) {
        setBadge(selectedBadge);
        setActiveTab('badges');
      }
    }

    // 6. Generate AI background if prompt provided
    if (action.payload?.prompt) {
      setActiveTab('bgchanger');
      handleGenerateAiBg(action.payload.prompt);
    }
  };

  // Social Preview Simulator
  const [socialPlatform, setSocialPlatform] = useState<SocialPlatformType>('none');

  // Master Canvas Ref
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const eraserCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Default Initial Tool States
  const [cropState, setCropState] = useState<CropState>({
    aspectRatio: '1:1',
    scale: 1,
    rotation: 0,
    offsetX: 0,
    offsetY: 0,
    flipH: false,
    flipV: false,
  });

  const [bgState, setBgState] = useState<BgState>({
    type: 'gradient',
    solidColor: '#075E54',
    gradient: {
      color1: '#059669',
      color2: '#111827',
      angle: 135,
      type: 'linear',
    },
    pattern: 'dots',
    customBgUrl: null,
    blurBackground: 0,
  });

  const [bgRemoval, setBgRemoval] = useState<BgRemovalState>({
    isRemoved: false,
    tolerance: 35,
    feather: 4,
    keyColor: '#FFFFFF',
    mode: 'auto',
    brushSize: 20,
    brushMode: 'erase',
    maskDataUrl: null,
  });

  const [frame, setFrame] = useState<FrameOption>(PRESET_FRAMES[1]); // Emerald Neon
  const [badge, setBadge] = useState<BadgeOption>(PRESET_BADGES[1]); // Blue Verified
  const [textOverlays, setTextOverlays] = useState<TextOverlay[]>([]);
  const [stickers, setStickers] = useState<StickerOverlay[]>([]);
  const [adjustments, setAdjustments] = useState<ImageAdjustments>({
    brightness: 5,
    contrast: 15,
    saturation: 10,
    sharpen: 25,
    vibrance: 10,
    warmth: 0,
    skinGlow: 10,
    blurBg: 0,
  });

  const removalInProgressRef = useRef<boolean>(false);
  const processedImageRef = useRef<HTMLImageElement | null>(null);

  // Load initial sample avatar by default if none loaded
  useEffect(() => {
    if (!rawImage && SAMPLE_AVATARS.length > 0) {
      loadImage(SAMPLE_AVATARS[0].url)
        .then((img) => setRawImage(img))
        .catch((err) => console.log('Sample image load error:', err));
    }
  }, []);

  // AI Background Removal Runner
  const handleRunAiBackgroundRemoval = async (imageToProcess?: HTMLImageElement | null) => {
    const img = imageToProcess || rawImage;
    if (!img) return;

    // Prevent duplicate concurrent execution loops
    if (removalInProgressRef.current) {
      console.log('AI background removal task already active, skipping duplicate trigger.');
      return;
    }

    // Skip re-processing if cutout is already generated for this exact image
    if (bgRemoval.aiCutoutImage && processedImageRef.current === img && !bgRemoval.error) {
      setBgRemoval((prev) => ({ ...prev, isRemoved: true, isLoading: false }));
      return;
    }

    removalInProgressRef.current = true;
    processedImageRef.current = img;

    setBgRemoval((prev) => ({
      ...prev,
      isRemoved: true,
      isLoading: true,
      progress: 5,
      error: null,
    }));

    try {
      const cutoutImg = await removeImageBackground(img, (pct) => {
        setBgRemoval((prev) => ({ ...prev, progress: pct }));
      });

      setBgRemoval((prev) => ({
        ...prev,
        isRemoved: true,
        isLoading: false,
        progress: 100,
        aiCutoutImage: cutoutImg,
        error: null,
      }));
    } catch (err: any) {
      console.error('AI background removal error:', err);
      setBgRemoval((prev) => ({
        ...prev,
        isLoading: false,
        error: err?.message || 'Failed to remove background automatically. Please click Retry.',
      }));
    } finally {
      removalInProgressRef.current = false;
    }
  };

  // AI Background Generation Handler
  const handleGenerateAiBg = async (promptText: string) => {
    setBgState((prev) => ({
      ...prev,
      type: 'ai',
      aiBgLoading: true,
      aiBgPrompt: promptText,
      aiBgError: null,
    }));

    try {
      const res = await fetch('/api/gemini/generate-bg', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: promptText }),
      });

      const data = await res.json();
      if (!data.success || !data.imageUrl) {
        throw new Error(data.error || 'Failed to generate AI background');
      }

      const bgImg = await loadImage(data.imageUrl);

      setBgState((prev) => ({
        ...prev,
        type: 'custom',
        customBgUrl: data.imageUrl,
        customBgImage: bgImg,
        aiBgLoading: false,
      }));

      // Enable AI background removal if raw image exists so cutout is seamlessly blended
      if (rawImage) {
        setBgRemoval((prev) => ({ ...prev, isRemoved: true }));
        handleRunAiBackgroundRemoval();
      }
    } catch (err: any) {
      console.error('AI background generation error:', err);
      setBgState((prev) => ({
        ...prev,
        aiBgLoading: false,
        aiBgError: err?.message || 'Failed to generate background',
      }));
    }
  };

  // HD Background Preset Selection Handler
  const handleSelectHdBgPreset = async (preset: HdBgPreset) => {
    setBgState((prev) => ({
      ...prev,
      type: 'custom',
      aiBgLoading: true,
      customBgUrl: preset.url,
      aiBgPrompt: preset.prompt,
    }));

    try {
      const bgImg = await loadImage(preset.url);
      setBgState((prev) => ({
        ...prev,
        type: 'custom',
        customBgUrl: preset.url,
        customBgImage: bgImg,
        aiBgLoading: false,
      }));

      // Enable AI subject cutout so person is cut out and blended into new HD preset background
      if (rawImage) {
        setBgRemoval((prev) => ({ ...prev, isRemoved: true }));
        handleRunAiBackgroundRemoval();
      }
    } catch (err) {
      console.error('Failed to load preset background:', err);
      setBgState((prev) => ({ ...prev, aiBgLoading: false }));
    }
  };

  // Custom Background Photo Upload Handler
  const handleUploadCustomBg = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const src = event.target?.result as string;
      if (src) {
        loadImage(src).then((bgImg) => {
          setBgState((prev) => ({
            ...prev,
            type: 'custom',
            customBgUrl: src,
            customBgImage: bgImg,
          }));
          if (rawImage) {
            setBgRemoval((prev) => ({ ...prev, isRemoved: true }));
            handleRunAiBackgroundRemoval();
          }
        });
      }
    };
    reader.readAsDataURL(file);
  };

  // Image File Upload Handler
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const src = event.target?.result as string;
      if (src) {
        loadImage(src)
          .then((img) => {
            processedImageRef.current = null;
            setRawImage(img);
            setBgRemoval((prev) => {
              const updated = { ...prev, aiCutoutImage: null, error: null, isLoading: false, progress: 0 };
              if (prev.isRemoved) {
                setTimeout(() => handleRunAiBackgroundRemoval(img), 50);
              }
              return updated;
            });
          })
          .catch((err) => {
            console.error('Failed to render uploaded photo:', err);
          });
      }
    };
    reader.onerror = (err) => {
      console.error('File reading error:', err);
    };
    reader.readAsDataURL(file);
  };

  // Sample Avatar Selection Handler
  const handleSelectSampleAvatar = (avatar: SampleAvatar) => {
    loadImage(avatar.url).then((img) => {
      processedImageRef.current = null;
      setRawImage(img);
      setBgRemoval((prev) => {
        const updated = { ...prev, aiCutoutImage: null, error: null, isLoading: false, progress: 0 };
        if (prev.isRemoved) {
          setTimeout(() => handleRunAiBackgroundRemoval(img), 50);
        }
        return updated;
      });
    });
  };

  // Apply Template Preset
  const handleSelectTemplate = (tmpl: DPTemplate) => {
    if (tmpl.bgState) setBgState((prev) => ({ ...prev, ...tmpl.bgState }));
    if (tmpl.adjustments) setAdjustments((prev) => ({ ...prev, ...tmpl.adjustments }));
    if (tmpl.frame) setFrame(tmpl.frame);
    if (tmpl.badge) setBadge(tmpl.badge);
    if (tmpl.textOverlays) setTextOverlays(tmpl.textOverlays);
  };

  // Reset Editor All
  const handleResetAll = () => {
    setCropState({
      aspectRatio: '1:1',
      scale: 1,
      rotation: 0,
      offsetX: 0,
      offsetY: 0,
      flipH: false,
      flipV: false,
    });
    setBgRemoval({
      isRemoved: false,
      tolerance: 35,
      feather: 4,
      keyColor: '#FFFFFF',
      mode: 'auto',
      brushSize: 20,
      brushMode: 'erase',
      maskDataUrl: null,
    });
    setFrame(PRESET_FRAMES[0]);
    setBadge(PRESET_BADGES[0]);
    setTextOverlays([]);
    setStickers([]);
    setAdjustments({
      brightness: 0,
      contrast: 0,
      saturation: 0,
      sharpen: 0,
      vibrance: 0,
      warmth: 0,
      skinGlow: 0,
      blurBg: 0,
    });
  };

  const handleClearEraserMask = () => {
    if (eraserCanvasRef.current) {
      const ctx = eraserCanvasRef.current.getContext('2d');
      if (ctx) ctx.clearRect(0, 0, eraserCanvasRef.current.width, eraserCanvasRef.current.height);
    }
  };

  if (showSplash) {
    return <SplashScreen onStart={() => setShowSplash(false)} />;
  }

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Global Header */}
      <Header
        onOpenSampleModal={() => setIsSampleOpen(true)}
        onOpenExportModal={() => setIsExportOpen(true)}
        onOpenGeminiModal={() => setIsGeminiOpen(true)}
        onOpenAssistant={() => setIsAssistantOpen(true)}
        onResetAll={handleResetAll}
        onImageUpload={handleImageUpload}
        hasImageLoaded={!!rawImage}
      />

      {/* Main Studio Workspace */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-3 sm:p-6 flex flex-col lg:flex-row gap-6">
        {/* Left Column: Interactive Canvas & Simulator */}
        <PhotoEditor
          rawImage={rawImage}
          onImageUpload={handleImageUpload}
          onOpenSampleModal={() => setIsSampleOpen(true)}
          cropState={cropState}
          bgState={bgState}
          bgRemoval={bgRemoval}
          frame={frame}
          badge={badge}
          textOverlays={textOverlays}
          stickers={stickers}
          adjustments={adjustments}
          socialPlatform={socialPlatform}
          setSocialPlatform={setSocialPlatform}
          eraserCanvasRef={eraserCanvasRef}
          onRetryAiRemoveBg={() => handleRunAiBackgroundRemoval()}
        />

        {/* Right Column: Studio Tools Control Panel */}
        <div className="w-full lg:w-[460px] bg-neutral-900/80 border border-neutral-800 rounded-3xl p-4 flex flex-col justify-between shadow-xl backdrop-blur-md shrink-0">
          <div>
            {/* Tool Category Tabs */}
            <div className="flex items-center gap-1 overflow-x-auto pb-2 border-b border-neutral-800 scrollbar-none mb-4">
              {[
                { id: 'templates', label: 'Templates', icon: Sparkles },
                { id: 'bgremover', label: 'AI Cutout', icon: Scissors },
                { id: 'enhancer', label: 'Enhance', icon: Sliders },
                { id: 'crop', label: 'Crop', icon: Crop },
                { id: 'bgchanger', label: 'Background', icon: Palette },
                { id: 'frames', label: 'Rings', icon: Circle },
                { id: 'badges', label: 'Badges', icon: BadgeCheck },
                { id: 'stickers', label: 'Stickers', icon: Smile },
                { id: 'blur', label: 'Blur', icon: Droplet },
                { id: 'compressor', label: 'Size', icon: HardDrive },
              ].map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 shrink-0 transition-all cursor-pointer ${
                      isActive
                        ? 'bg-emerald-500 text-neutral-950 shadow-md shadow-emerald-500/20'
                        : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/60'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Active Tool View */}
            <div className="py-2">
              {activeTab === 'templates' && (
                <TemplateSelector
                  onSelectTemplate={handleSelectTemplate}
                />
              )}

              {activeTab === 'bgremover' && (
                <BgRemoverTool
                  bgRemoval={bgRemoval}
                  setBgRemoval={setBgRemoval}
                  onClearEraserMask={handleClearEraserMask}
                  onRunAiRemoveBg={() => handleRunAiBackgroundRemoval()}
                  hasImage={!!rawImage}
                />
              )}

              {activeTab === 'enhancer' && (
                <EnhancerTool
                  adjustments={adjustments}
                  setAdjustments={setAdjustments}
                />
              )}

              {activeTab === 'crop' && (
                <CropTool cropState={cropState} setCropState={setCropState} />
              )}

              {activeTab === 'bgchanger' && (
                <BgChangerTool
                  bgState={bgState}
                  setBgState={setBgState}
                  onGenerateAiBg={handleGenerateAiBg}
                  onSelectHdBgPreset={handleSelectHdBgPreset}
                  onUploadCustomBg={handleUploadCustomBg}
                />
              )}

              {activeTab === 'frames' && (
                <FramesTool frame={frame} setFrame={setFrame} />
              )}

              {activeTab === 'badges' && (
                <TextBadgeTool
                  badge={badge}
                  setBadge={setBadge}
                  textOverlays={textOverlays}
                  setTextOverlays={setTextOverlays}
                />
              )}

              {activeTab === 'stickers' && (
                <StickersTool stickers={stickers} setStickers={setStickers} />
              )}

              {activeTab === 'blur' && (
                <BlurTool bgState={bgState} setBgState={setBgState} />
              )}

              {activeTab === 'compressor' && (
                <CompressorTool canvasRef={canvasRef} />
              )}
            </div>
          </div>

          {/* Quick Action Footer */}
          <div className="pt-4 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400">
            <span className="flex items-center gap-1 text-[11px]">
              <span className="w-2 h-2 rounded-full bg-emerald-500" /> Auto-Render Active
            </span>
            <button
              onClick={() => setIsExportOpen(true)}
              className="text-emerald-400 font-bold hover:underline"
            >
              Export HD Photo &rarr;
            </button>
          </div>
        </div>
      </main>

      {/* Floating AI Assistant Trigger */}
      <button
        onClick={() => setIsAssistantOpen(true)}
        className="fixed bottom-5 right-5 z-40 p-3.5 rounded-full bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-neutral-950 shadow-2xl shadow-emerald-500/40 border border-emerald-400/40 flex items-center gap-2 font-bold text-xs transition-all cursor-pointer active:scale-95 group"
        title="Ask AI Assistant"
      >
        <Sparkles className="w-5 h-5 text-neutral-950 group-hover:rotate-12 transition-transform" />
        <span className="hidden sm:inline font-extrabold text-neutral-950">Ask AI Assistant</span>
        <span className="flex h-2.5 w-2.5 relative">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-neutral-950 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-neutral-950"></span>
        </span>
      </button>

      {/* Modals */}
      <ExportShareModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        canvasRef={canvasRef}
      />

      <SampleAvatarsModal
        isOpen={isSampleOpen}
        onClose={() => setIsSampleOpen(false)}
        onSelectAvatar={handleSelectSampleAvatar}
      />

      <GeminiAdviceModal
        isOpen={isGeminiOpen}
        onClose={() => setIsGeminiOpen(false)}
      />

      <AiAssistantDrawer
        isOpen={isAssistantOpen}
        onClose={() => setIsAssistantOpen(false)}
        currentTab={activeTab}
        hasImage={!!rawImage}
        onPerformAssistantAction={handlePerformAssistantAction}
      />
    </div>
  );
}
