export type AspectRatioType = '1:1' | '4:3' | '16:9' | '9:16' | 'circle' | 'custom';

export type FilterPresetType = 'normal' | 'auto-hd' | 'portrait-glow' | 'warm-studio' | 'cyber-emerald' | 'bw-dramatic' | 'vintage-film' | 'soft-dream';

export type BgType = 'ai' | 'gradient' | 'solid' | 'pattern' | 'custom' | 'transparent';

export type SocialPlatformType = 'none' | 'whatsapp' | 'facebook' | 'instagram' | 'linkedin';

export interface ImageAdjustments {
  brightness: number;  // -100 to 100
  contrast: number;    // -100 to 100
  saturation: number;  // -100 to 100
  sharpen: number;     // 0 to 100
  vibrance: number;    // -100 to 100
  warmth: number;      // -100 to 100
  skinGlow: number;    // 0 to 100
  blurBg: number;      // 0 to 30px
}

export interface CropState {
  aspectRatio: AspectRatioType;
  scale: number;        // 0.5 to 3.0
  rotation: number;     // -180 to 180
  offsetX: number;      // -200 to 200
  offsetY: number;      // -200 to 200
  flipH: boolean;
  flipV: boolean;
}

export interface BgState {
  type: BgType;
  solidColor: string;
  gradient: {
    color1: string;
    color2: string;
    angle: number;
    type: 'linear' | 'radial';
  };
  pattern: string; // 'dots' | 'grid' | 'waves' | 'bokeh'
  customBgUrl: string | null;
  customBgImage?: HTMLImageElement | null;
  aiBgPrompt?: string;
  aiBgLoading?: boolean;
  aiBgError?: string | null;
  blurBackground: number; // 0 to 30
}

export interface BgRemovalState {
  isRemoved: boolean;
  tolerance: number; // 5 to 80
  feather: number;    // 0 to 20
  keyColor: string;  // Hex color key
  mode: 'auto' | 'manual';
  brushSize: number; // 5 to 50
  brushMode: 'erase' | 'restore';
  maskDataUrl: string | null; // For manual eraser canvas overlay
  isLoading?: boolean;
  progress?: number;
  aiCutoutImage?: HTMLImageElement | null;
  error?: string | null;
}

export interface FrameOption {
  id: string;
  name: string;
  type: 'none' | 'solid-ring' | 'gradient-ring' | 'dashed-ring' | 'neon-glow' | 'double-ring' | 'gold-ring' | 'instagram-story' | 'whatsapp-ring' | 'linkedin-openwork';
  color1: string;
  color2?: string;
  width: number; // 2 to 20
  inset: number; // 0 to 30
}

export interface BadgeOption {
  id: string;
  name: string;
  type: 'verified-blue' | 'whatsapp-green' | 'gold-star' | 'open-to-work' | 'pro-pill' | 'creator-pill' | 'custom-pill' | 'none';
  text?: string;
  position: 'bottom-right' | 'bottom-center' | 'top-right' | 'top-left';
  size: number; // 0.8 to 1.5
  bgColor?: string;
  textColor?: string;
}

export interface TextOverlay {
  id: string;
  text: string;
  fontFamily: string;
  fontSize: number;
  color: string;
  bgColor: string;
  isCurved: boolean;
  hasShadow: boolean;
  hasOutline: boolean;
  outlineColor: string;
  positionY: number; // percentage from top 10% to 90%
}

export interface StickerOverlay {
  id: string;
  emojiOrUrl: string;
  x: number; // 0 to 100%
  y: number; // 0 to 100%
  size: number; // 20 to 100
  rotation: number; // -180 to 180
}

export interface DPTemplate {
  id: string;
  name: string;
  category: 'Corporate' | 'Tech' | 'Social' | 'Creative' | 'Aesthetic' | 'Luxury';
  previewImage?: string;
  bgState: Partial<BgState>;
  adjustments: Partial<ImageAdjustments>;
  frame: FrameOption;
  badge: BadgeOption;
  textOverlays?: TextOverlay[];
}

export interface SampleAvatar {
  id: string;
  name: string;
  role: string;
  url: string;
}

export interface CompressionSettings {
  quality: number; // 0.1 to 1.0
  format: 'image/jpeg' | 'image/png' | 'image/webp';
  targetWidth: number; // 800, 1080, 2048
}
