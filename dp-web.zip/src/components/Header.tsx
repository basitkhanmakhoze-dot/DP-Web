import React from 'react';
import { Camera, Sparkles, Image as ImageIcon, RotateCcw, Download, Share2, Bot, Layers, Upload } from 'lucide-react';

interface HeaderProps {
  onOpenSampleModal: () => void;
  onOpenExportModal: () => void;
  onOpenGeminiModal: () => void;
  onOpenAssistant: () => void;
  onResetAll: () => void;
  onImageUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  hasImageLoaded: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSampleModal,
  onOpenExportModal,
  onOpenGeminiModal,
  onOpenAssistant,
  onResetAll,
  onImageUpload,
  hasImageLoaded,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-neutral-950/90 backdrop-blur-md border-b border-neutral-800/80 px-4 sm:px-6 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Brand Header */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-500 to-emerald-700 p-0.5 shadow-md shadow-emerald-500/20 flex items-center justify-center text-neutral-950 font-bold shrink-0">
            <Camera className="w-5 h-5 text-neutral-950" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-extrabold text-neutral-100 tracking-tight leading-none">
                DP <span className="text-emerald-400">Web</span>
              </h1>
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Material 3
              </span>
            </div>
            <p className="text-[11px] text-neutral-400 hidden sm:block">
              Create Professional Display Pictures in Seconds
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <label className="px-3 py-1.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 hover:bg-emerald-500/25 text-emerald-300 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-sm">
            <Upload className="w-3.5 h-3.5 text-emerald-400" />
            <span>Upload from Gallery</span>
            <input
              type="file"
              accept="image/jpeg,image/jpg,image/png,image/webp,image/*"
              onChange={onImageUpload}
              onClick={(e) => {
                (e.target as HTMLInputElement).value = '';
              }}
              className="hidden"
            />
          </label>

          <button
            onClick={onOpenAssistant}
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500/20 via-emerald-600/20 to-teal-500/20 border border-emerald-500/40 hover:border-emerald-400 text-emerald-300 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-sm shadow-emerald-500/10 group relative"
            title="Open AI Assistant to ask questions or edit via chat"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400 group-hover:rotate-12 transition-transform" />
            <span>AI Assistant</span>
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
          </button>

          <button
            onClick={onOpenSampleModal}
            className="px-3 py-1.5 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-neutral-200 text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
            title="Load sample avatars"
          >
            <ImageIcon className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden md:inline">Sample Photos</span>
          </button>

          <button
            onClick={onOpenGeminiModal}
            className="px-3 py-1.5 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-neutral-300 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
            title="AI Style Advice & Status Bios"
          >
            <Bot className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">AI Captions</span>
          </button>

          {hasImageLoaded && (
            <button
              onClick={onResetAll}
              className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 hover:text-red-400 text-neutral-400 text-xs transition-all cursor-pointer active:scale-95"
              title="Reset Editor"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          )}

          <button
            onClick={onOpenExportModal}
            className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-neutral-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/20 transition-all cursor-pointer active:scale-95"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Save HD</span>
          </button>
        </div>
      </div>
    </header>
  );
};
