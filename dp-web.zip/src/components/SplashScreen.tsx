import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Camera, ShieldCheck, Zap, Image, CheckCircle2, ArrowRight } from 'lucide-react';

interface SplashScreenProps {
  onStart: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onStart }) => {
  return (
    <div className="fixed inset-0 z-50 bg-neutral-950 text-neutral-100 flex flex-col justify-between p-6 sm:p-12 overflow-hidden selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Background Glows */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-emerald-500/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-emerald-600/10 rounded-full blur-[100px] pointer-events-none" />

      {/* Top Bar */}
      <div className="relative z-10 flex items-center justify-between max-w-5xl mx-auto w-full">
        <div className="flex items-center gap-2 bg-neutral-900/80 border border-neutral-800 px-3 py-1.5 rounded-full text-xs font-medium text-emerald-400">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
          <span>Material 3 Edition</span>
        </div>
        <button
          onClick={onStart}
          className="text-xs text-neutral-400 hover:text-neutral-200 transition-colors flex items-center gap-1"
        >
          Skip Intro <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Center Hero */}
      <div className="relative z-10 max-w-3xl mx-auto w-full text-center my-auto py-8">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
          className="inline-flex items-center justify-center p-4 mb-6 rounded-3xl bg-gradient-to-br from-emerald-500 to-emerald-700 shadow-xl shadow-emerald-500/20 ring-4 ring-emerald-500/10"
        >
          <Camera className="w-12 h-12 text-white" />
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-neutral-100 mb-4">
            DP <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-200">Web</span>
          </h1>
          <p className="text-emerald-400 text-lg sm:text-2xl font-medium mb-3">
            Create Professional Display Pictures in Seconds
          </p>
          <p className="text-neutral-400 text-sm sm:text-base max-w-xl mx-auto leading-relaxed">
            AI Background Removal, HD Photo Enhancer, Social Media Presets for WhatsApp, Instagram, Facebook &amp; LinkedIn with HD Export.
          </p>
        </motion.div>

        {/* Feature Badges Grid */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
          className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-2xl mx-auto mt-8 text-left"
        >
          <div className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex items-center gap-2.5">
            <Zap className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="text-xs font-medium text-neutral-300">AI Background Removal</span>
          </div>
          <div className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex items-center gap-2.5">
            <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="text-xs font-medium text-neutral-300">AI Photo Enhancer</span>
          </div>
          <div className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex items-center gap-2.5">
            <Image className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="text-xs font-medium text-neutral-300">Social Media Presets</span>
          </div>
          <div className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex items-center gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="text-xs font-medium text-neutral-300">Save in 4K HD Quality</span>
          </div>
        </motion.div>

        {/* Action Button */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.5 }}
          className="mt-10"
        >
          <button
            onClick={onStart}
            className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-neutral-950 font-bold text-base shadow-lg shadow-emerald-500/25 transition-all flex items-center justify-center gap-3 mx-auto group cursor-pointer active:scale-95"
          >
            <span>Open DP Web Studio</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </motion.div>
      </div>

      {/* Footer */}
      <div className="relative z-10 max-w-5xl mx-auto w-full text-center text-xs text-neutral-500 border-t border-neutral-900 pt-4 flex flex-col sm:flex-row items-center justify-between gap-2">
        <p>© DP Web — Professional Display Picture Editor</p>
        <div className="flex items-center gap-2 text-neutral-400">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          <span>Ready for Instant Creation</span>
        </div>
      </div>
    </div>
  );
};
