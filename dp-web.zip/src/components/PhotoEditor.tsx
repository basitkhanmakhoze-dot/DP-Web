import React, { useRef, useEffect, useState } from 'react';
import {
  Upload,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Image as ImageIcon,
  MessageCircle,
  Instagram,
  Facebook,
  Linkedin,
  Eraser,
  Sparkles,
  Eye,
  RefreshCw,
  AlertCircle,
} from 'lucide-react';
import {
  SocialPlatformType,
  CropState,
  BgState,
  BgRemovalState,
  FrameOption,
  BadgeOption,
  TextOverlay,
  StickerOverlay,
  ImageAdjustments,
} from '../types';
import { renderMasterDP, createCutoutCanvas, applyAdjustments } from '../utils/canvasUtils';

interface PhotoEditorProps {
  rawImage: HTMLImageElement | null;
  onImageUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onOpenSampleModal: () => void;
  cropState: CropState;
  bgState: BgState;
  bgRemoval: BgRemovalState;
  frame: FrameOption;
  badge: BadgeOption;
  textOverlays: TextOverlay[];
  stickers: StickerOverlay[];
  adjustments: ImageAdjustments;
  socialPlatform: SocialPlatformType;
  setSocialPlatform: (p: SocialPlatformType) => void;
  eraserCanvasRef: React.RefObject<HTMLCanvasElement | null>;
  onEraserDraw?: () => void;
  onRetryAiRemoveBg?: () => void;
}

export const PhotoEditor: React.FC<PhotoEditorProps> = ({
  rawImage,
  onImageUpload,
  onOpenSampleModal,
  cropState,
  bgState,
  bgRemoval,
  frame,
  badge,
  textOverlays,
  stickers,
  adjustments,
  socialPlatform,
  setSocialPlatform,
  eraserCanvasRef,
  onEraserDraw,
  onRetryAiRemoveBg,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [isDrawingEraser, setIsDrawingEraser] = useState<boolean>(false);

  // Render Engine effect on state updates
  useEffect(() => {
    if (!rawImage || !canvasRef.current) return;

    // 1. Generate base cutout canvas
    const cutoutCanvas = createCutoutCanvas(
      rawImage,
      bgRemoval,
      eraserCanvasRef.current
    );

    // 2. Apply color adjustments
    const adjustedCutout = applyAdjustments(cutoutCanvas, adjustments);

    // 3. Render final master DP composition onto canvas
    renderMasterDP(
      canvasRef.current,
      adjustedCutout,
      rawImage,
      cropState,
      bgState,
      frame,
      badge,
      textOverlays,
      stickers,
      1080
    );
  }, [
    rawImage,
    cropState,
    bgState,
    bgRemoval,
    frame,
    badge,
    textOverlays,
    stickers,
    adjustments,
  ]);

  // Setup Manual Eraser Canvas size if image changes
  useEffect(() => {
    if (rawImage && eraserCanvasRef.current) {
      eraserCanvasRef.current.width = rawImage.width;
      eraserCanvasRef.current.height = rawImage.height;
    }
  }, [rawImage]);

  // Eraser Brush Mouse Event Handlers
  const handleEraserMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (bgRemoval.mode !== 'manual' || !eraserCanvasRef.current) return;
    setIsDrawingEraser(true);
    drawEraserStroke(e);
  };

  const handleEraserMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawingEraser || bgRemoval.mode !== 'manual') return;
    drawEraserStroke(e);
  };

  const handleEraserMouseUp = () => {
    if (isDrawingEraser) {
      setIsDrawingEraser(false);
      if (onEraserDraw) onEraserDraw();
    }
  };

  const drawEraserStroke = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const eraserCanvas = eraserCanvasRef.current;
    if (!eraserCanvas || !canvasRef.current) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const scaleX = eraserCanvas.width / rect.width;
    const scaleY = eraserCanvas.height / rect.height;

    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    const ctx = eraserCanvas.getContext('2d');
    if (!ctx) return;

    ctx.save();
    ctx.beginPath();
    ctx.arc(x, y, bgRemoval.brushSize * scaleX, 0, Math.PI * 2);

    if (bgRemoval.brushMode === 'erase') {
      ctx.fillStyle = '#000000';
      ctx.fill();
    } else {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.fill();
    }
    ctx.restore();
  };

  // Drag and drop event handlers
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const fakeEvent = {
        target: { files: [file] },
      } as unknown as React.ChangeEvent<HTMLInputElement>;
      onImageUpload(fakeEvent);
    }
  };

  if (!rawImage) {
    return (
      <div
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        className="flex-1 flex flex-col items-center justify-center p-6 sm:p-12 text-center bg-neutral-900/40 rounded-3xl border-2 border-dashed border-neutral-800 my-4 transition-all hover:border-emerald-500/50 group"
      >
        <div className="w-16 h-16 rounded-3xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 mb-6 group-hover:scale-110 transition-transform">
          <Upload className="w-8 h-8" />
        </div>
        <h2 className="text-xl sm:text-2xl font-bold text-neutral-100 mb-2">
          Upload Photo from Gallery
        </h2>
        <p className="text-sm text-neutral-400 max-w-md mb-4 leading-relaxed">
          Select any portrait or photo from your device gallery. DP Web will convert it into a high-res profile picture.
        </p>

        {/* Supported Formats Chips */}
        <div className="flex items-center gap-2 mb-6">
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-emerald-400 border border-neutral-700">JPG</span>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-emerald-400 border border-neutral-700">JPEG</span>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-emerald-400 border border-neutral-700">PNG</span>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-emerald-400 border border-neutral-700">WEBP</span>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-3">
          <label className="px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-neutral-950 font-bold text-sm shadow-lg shadow-emerald-500/20 transition-all cursor-pointer active:scale-95 flex items-center gap-2">
            <Upload className="w-4 h-4" />
            <span>Upload from Gallery</span>
            <input
              type="file"
              accept="image/jpeg,image/jpg,image/png,image/webp,image/*"
              onChange={onImageUpload}
              onClick={(e) => {
                (e.target as HTMLInputElement).value = '';
              }}
              className="hidden"
            />
          </label>

          <button
            onClick={onOpenSampleModal}
            className="px-6 py-3 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-neutral-200 text-sm font-semibold transition-all cursor-pointer active:scale-95 flex items-center gap-2"
          >
            <ImageIcon className="w-4 h-4 text-emerald-400" />
            <span>Try Sample Avatar</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-4 relative min-h-[480px]">
      {/* Platform Preview Simulator Toggle Bar */}
      <div className="mb-4 flex items-center justify-between w-full max-w-[420px]">
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-neutral-900 border border-neutral-800 overflow-x-auto max-w-full">
          <span className="text-[11px] font-semibold text-neutral-400 px-2 flex items-center gap-1">
            <Eye className="w-3.5 h-3.5 text-emerald-400" />
            Preview:
          </span>

          <button
            onClick={() => setSocialPlatform('none')}
            className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              socialPlatform === 'none'
                ? 'bg-emerald-500 text-neutral-950 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Full
          </button>

          <button
            onClick={() => setSocialPlatform('whatsapp')}
            className={`px-3 py-1 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              socialPlatform === 'whatsapp'
                ? 'bg-emerald-500 text-neutral-950 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span>WhatsApp</span>
          </button>

          <button
            onClick={() => setSocialPlatform('instagram')}
            className={`px-3 py-1 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              socialPlatform === 'instagram'
                ? 'bg-emerald-500 text-neutral-950 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Instagram className="w-3.5 h-3.5 text-pink-400" />
            <span>IG</span>
          </button>

          <button
            onClick={() => setSocialPlatform('linkedin')}
            className={`px-3 py-1 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              socialPlatform === 'linkedin'
                ? 'bg-emerald-500 text-neutral-950 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Linkedin className="w-3.5 h-3.5 text-blue-500" />
            <span>LinkedIn</span>
          </button>
        </div>

        {/* Change Photo / Gallery upload button when image is loaded */}
        <label className="p-2 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-emerald-500/50 text-neutral-300 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 shrink-0" title="Change Photo from Gallery">
          <Upload className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden sm:inline">Change Photo</span>
          <input
            type="file"
            accept="image/jpeg,image/jpg,image/png,image/webp,image/*"
            onChange={onImageUpload}
            onClick={(e) => {
              (e.target as HTMLInputElement).value = '';
            }}
            className="hidden"
          />
        </label>
      </div>

      {/* Main Canvas Canvas Frame */}
      <div
        className="relative flex items-center justify-center rounded-3xl overflow-hidden shadow-2xl bg-neutral-900 border border-neutral-800 transition-all"
        style={{
          width: '100%',
          maxWidth: '420px',
          aspectRatio: '1/1',
          transform: `scale(${zoomLevel / 100})`,
        }}
      >
        {/* Render Canvas */}
        <canvas
          ref={canvasRef}
          className={`w-full h-full object-contain ${
            cropState.aspectRatio === 'circle' ? 'rounded-full' : 'rounded-2xl'
          }`}
        />

        {/* AI Processing Loading Overlay */}
        {(bgRemoval.isLoading || bgState.aiBgLoading) && (
          <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-neutral-950/85 backdrop-blur-md p-4 text-center rounded-3xl">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 mb-3 animate-pulse">
              <Sparkles className="w-6 h-6 animate-spin" />
            </div>
            <h4 className="text-xs font-bold text-neutral-100 uppercase tracking-wider mb-1">
              {bgState.aiBgLoading ? 'Generating AI Background...' : 'AI Removing Background...'}
            </h4>
            <p className="text-[11px] text-neutral-400 mb-3 max-w-[220px]">
              {bgState.aiBgLoading
                ? 'Creating 1080×1080 studio background & blending cutout'
                : 'Neural network segmenting portrait subject'}
            </p>
            <div className="w-48 bg-neutral-800 rounded-full h-1.5 overflow-hidden mb-1">
              <div
                className="bg-emerald-500 h-full transition-all duration-200 rounded-full"
                style={{
                  width: bgState.aiBgLoading
                    ? '85%'
                    : `${bgRemoval.progress || 10}%`,
                }}
              />
            </div>
            <span className="text-[10px] font-mono text-emerald-400 font-bold">
              {bgState.aiBgLoading ? 'HD AI Render...' : `${bgRemoval.progress || 10}%`}
            </span>
          </div>
        )}

        {/* AI Error Overlay with Retry button */}
        {!bgRemoval.isLoading && bgRemoval.error && (
          <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-neutral-950/90 backdrop-blur-md p-5 text-center rounded-3xl space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-1">
                Background Removal Error
              </h4>
              <p className="text-[11px] text-neutral-300 max-w-[240px] leading-relaxed">
                {bgRemoval.error}
              </p>
            </div>
            {onRetryAiRemoveBg && (
              <button
                onClick={onRetryAiRemoveBg}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-neutral-950 font-extrabold text-xs flex items-center gap-1.5 shadow-lg cursor-pointer active:scale-95 transition-all"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Retry AI Background Removal</span>
              </button>
            )}
          </div>
        )}

        {/* Manual Eraser Overlay Canvas */}
        {bgRemoval.mode === 'manual' && (
          <canvas
            ref={eraserCanvasRef}
            onMouseDown={handleEraserMouseDown}
            onMouseMove={handleEraserMouseMove}
            onMouseUp={handleEraserMouseUp}
            className="absolute inset-0 w-full h-full cursor-crosshair z-20"
          />
        )}

        {/* WhatsApp Chat Simulator Frame Overlay */}
        {socialPlatform === 'whatsapp' && (
          <div className="absolute inset-0 z-10 pointer-events-none flex flex-col justify-between p-3 bg-neutral-950/20 backdrop-blur-[1px]">
            <div className="bg-[#075E54] text-white p-2.5 rounded-xl shadow-md flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-full bg-emerald-400/20 border border-emerald-400 flex items-center justify-center text-xs font-bold">
                DP
              </div>
              <div>
                <p className="text-xs font-bold leading-none">WhatsApp Profile</p>
                <p className="text-[10px] text-emerald-200">Online</p>
              </div>
            </div>
            <div className="bg-[#128C7E]/90 text-white p-2 rounded-xl text-[10px] text-center font-medium">
              1:1 Perfect Display Picture Fit
            </div>
          </div>
        )}

        {/* Instagram Profile Simulator Overlay */}
        {socialPlatform === 'instagram' && (
          <div className="absolute inset-0 z-10 pointer-events-none flex items-center justify-center">
            <div className="w-[85%] h-[85%] rounded-full ring-4 ring-gradient-to-tr from-yellow-400 via-red-500 to-purple-600 shadow-2xl" />
          </div>
        )}

        {/* Facebook Cover Simulator Overlay */}
        {socialPlatform === 'facebook' && (
          <div className="absolute inset-0 z-10 pointer-events-none flex flex-col justify-end p-4 bg-gradient-to-t from-neutral-950/80 via-transparent to-transparent">
            <div className="bg-blue-600 text-white px-3 py-1 rounded-full text-[10px] font-bold w-max mb-1">
              Facebook DP Guide
            </div>
            <p className="text-[11px] text-neutral-300">Circular cropping active</p>
          </div>
        )}

        {/* LinkedIn Simulator Overlay */}
        {socialPlatform === 'linkedin' && (
          <div className="absolute inset-0 z-10 pointer-events-none flex flex-col justify-between p-3 border-4 border-blue-600 rounded-3xl">
            <div className="bg-[#0A66C2] text-white px-2.5 py-1 rounded-lg text-[10px] font-bold w-max">
              LinkedIn
            </div>
            <div className="bg-neutral-900/90 text-blue-400 text-[10px] font-bold px-2.5 py-1 rounded-lg text-center">
              #OPENTOWORK Ready
            </div>
          </div>
        )}
      </div>

      {/* Canvas Controls Bar */}
      <div className="mt-4 flex items-center gap-2 bg-neutral-900 border border-neutral-800 px-3 py-1.5 rounded-full text-xs text-neutral-400">
        <button
          onClick={() => setZoomLevel((z) => Math.max(70, z - 10))}
          className="hover:text-neutral-200 p-1 rounded-md transition-colors"
          title="Zoom Out"
        >
          <ZoomOut className="w-3.5 h-3.5" />
        </button>
        <span className="font-mono text-[11px] text-neutral-300">{zoomLevel}%</span>
        <button
          onClick={() => setZoomLevel((z) => Math.min(130, z + 10))}
          className="hover:text-neutral-200 p-1 rounded-md transition-colors"
          title="Zoom In"
        >
          <ZoomIn className="w-3.5 h-3.5" />
        </button>
        <div className="w-px h-3 bg-neutral-800 my-auto mx-1" />
        <button
          onClick={() => setZoomLevel(100)}
          className="hover:text-neutral-200 p-1 rounded-md transition-colors flex items-center gap-1 text-[10px]"
        >
          <Maximize2 className="w-3 h-3" /> Fit
        </button>
        <div className="w-px h-3 bg-neutral-800 my-auto mx-1" />
        <span className="text-[10px] text-emerald-400 font-medium">1080 x 1080 HD</span>
      </div>
    </div>
  );
};
