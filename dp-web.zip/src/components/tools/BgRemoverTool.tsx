import React from 'react';
import { BgRemovalState } from '../../types';
import { Scissors, Eraser, RotateCcw, Brush, Sparkles, RefreshCw, CheckCircle2, AlertCircle } from 'lucide-react';

interface BgRemoverToolProps {
  bgRemoval: BgRemovalState;
  setBgRemoval: React.Dispatch<React.SetStateAction<BgRemovalState>>;
  onClearEraserMask: () => void;
  onRunAiRemoveBg: () => void;
  hasImage: boolean;
}

export const BgRemoverTool: React.FC<BgRemoverToolProps> = ({
  bgRemoval,
  setBgRemoval,
  onClearEraserMask,
  onRunAiRemoveBg,
  hasImage,
}) => {
  const handleToggle = (checked: boolean) => {
    setBgRemoval((prev) => ({ ...prev, isRemoved: checked }));
    if (checked && !bgRemoval.aiCutoutImage && !bgRemoval.isLoading && hasImage) {
      onRunAiRemoveBg();
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-bold text-neutral-200 flex items-center gap-1.5 uppercase tracking-wider">
          <Scissors className="w-3.5 h-3.5 text-emerald-400" />
          AI Background Remover
        </h3>
        <label className="relative inline-flex items-center cursor-pointer">
          <input
            type="checkbox"
            checked={bgRemoval.isRemoved}
            onChange={(e) => handleToggle(e.target.checked)}
            className="sr-only peer"
          />
          <div className="w-9 h-5 bg-neutral-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500" />
        </label>
      </div>

      {bgRemoval.isRemoved ? (
        <div className="space-y-3.5 bg-neutral-900/60 p-3.5 rounded-2xl border border-neutral-800">
          {/* AI Status Card */}
          <div className="p-3 rounded-xl bg-neutral-900/90 border border-emerald-500/30 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-emerald-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                {bgRemoval.isLoading
                  ? 'Processing AI Removal...'
                  : bgRemoval.aiCutoutImage
                  ? 'AI Subject Isolated'
                  : 'AI Removal Ready'}
              </span>
              {bgRemoval.aiCutoutImage && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Active
                </span>
              )}
            </div>

            {/* Progress Bar during loading */}
            {bgRemoval.isLoading && (
              <div className="space-y-1">
                <div className="w-full bg-neutral-800 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-emerald-500 h-full transition-all duration-200 rounded-full"
                    style={{ width: `${bgRemoval.progress || 10}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-[10px] text-neutral-400">
                  <span>Segmenting subject...</span>
                  <span className="font-mono text-emerald-400 font-bold">{bgRemoval.progress || 10}%</span>
                </div>
              </div>
            )}

            {bgRemoval.error && (
              <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 space-y-1">
                <p className="text-[10px] font-semibold flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{bgRemoval.error}</span>
                </p>
              </div>
            )}

            {/* Action Trigger Button */}
            <button
              onClick={onRunAiRemoveBg}
              disabled={bgRemoval.isLoading || !hasImage}
              className={`w-full py-2.5 rounded-xl text-neutral-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-md transition-all cursor-pointer active:scale-95 ${
                bgRemoval.error
                  ? 'bg-amber-400 hover:bg-amber-300'
                  : 'bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500'
              } disabled:opacity-50`}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${bgRemoval.isLoading ? 'animate-spin' : ''}`} />
              <span>
                {bgRemoval.error
                  ? 'Retry AI Background Removal'
                  : bgRemoval.aiCutoutImage
                  ? 'Re-Run AI Removal'
                  : 'Perform AI Background Removal'}
              </span>
            </button>
          </div>

          {/* Key Color Selection for Chroma Fine-Tuning */}
          <div>
            <label className="text-[11px] text-neutral-400 font-semibold mb-1.5 flex items-center justify-between">
              <span>Chroma / Color Masking Key</span>
              <span className="font-mono text-emerald-400">{bgRemoval.keyColor}</span>
            </label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={bgRemoval.keyColor}
                onChange={(e) =>
                  setBgRemoval((prev) => ({ ...prev, keyColor: e.target.value }))
                }
                className="w-8 h-8 rounded-lg bg-neutral-800 border border-neutral-700 cursor-pointer"
              />
              <div className="flex items-center gap-1.5 flex-1 overflow-x-auto">
                {['#FFFFFF', '#000000', '#00FF00', '#F3F4F6', '#1F2937', '#0000FF'].map((color) => (
                  <button
                    key={color}
                    onClick={() => setBgRemoval((prev) => ({ ...prev, keyColor: color }))}
                    className="w-6 h-6 rounded-md border border-neutral-700 shrink-0 transition-transform active:scale-95"
                    style={{ backgroundColor: color }}
                    title={color}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Color Tolerance Slider */}
          <div>
            <div className="flex items-center justify-between text-[11px] text-neutral-400 mb-1">
              <span>Color Tolerance / Edge Cutout</span>
              <span className="font-mono text-neutral-200">{bgRemoval.tolerance}</span>
            </div>
            <input
              type="range"
              min="5"
              max="100"
              value={bgRemoval.tolerance}
              onChange={(e) =>
                setBgRemoval((prev) => ({ ...prev, tolerance: Number(e.target.value) }))
              }
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          {/* Edge Feathering Slider */}
          <div>
            <div className="flex items-center justify-between text-[11px] text-neutral-400 mb-1">
              <span>Edge Feathering &amp; Smoothness</span>
              <span className="font-mono text-neutral-200">{bgRemoval.feather}px</span>
            </div>
            <input
              type="range"
              min="0"
              max="20"
              value={bgRemoval.feather}
              onChange={(e) =>
                setBgRemoval((prev) => ({ ...prev, feather: Number(e.target.value) }))
              }
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          {/* Manual Eraser / Restore Brush */}
          <div className="pt-2 border-t border-neutral-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-semibold text-neutral-300 flex items-center gap-1">
                <Eraser className="w-3.5 h-3.5 text-emerald-400" /> Manual Brush Touch-Up
              </span>
              <button
                onClick={onClearEraserMask}
                className="text-[10px] text-red-400 hover:text-red-300 flex items-center gap-1 font-medium"
              >
                <RotateCcw className="w-3 h-3" /> Reset Mask
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 mb-2">
              <button
                onClick={() =>
                  setBgRemoval((prev) => ({
                    ...prev,
                    mode: prev.mode === 'manual' && prev.brushMode === 'erase' ? 'auto' : 'manual',
                    brushMode: 'erase',
                  }))
                }
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  bgRemoval.mode === 'manual' && bgRemoval.brushMode === 'erase'
                    ? 'bg-emerald-500 text-neutral-950 shadow-sm'
                    : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                }`}
              >
                <Eraser className="w-3.5 h-3.5" /> Eraser Brush
              </button>

              <button
                onClick={() =>
                  setBgRemoval((prev) => ({
                    ...prev,
                    mode: prev.mode === 'manual' && prev.brushMode === 'restore' ? 'auto' : 'manual',
                    brushMode: 'restore',
                  }))
                }
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  bgRemoval.mode === 'manual' && bgRemoval.brushMode === 'restore'
                    ? 'bg-emerald-500 text-neutral-950 shadow-sm'
                    : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                }`}
              >
                <Brush className="w-3.5 h-3.5" /> Restore Brush
              </button>
            </div>

            {bgRemoval.mode === 'manual' && (
              <div>
                <div className="flex items-center justify-between text-[10px] text-neutral-400 mb-1">
                  <span>Brush Diameter</span>
                  <span className="font-mono text-neutral-200">{bgRemoval.brushSize}px</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="60"
                  value={bgRemoval.brushSize}
                  onChange={(e) =>
                    setBgRemoval((prev) => ({ ...prev, brushSize: Number(e.target.value) }))
                  }
                  className="w-full accent-emerald-500 cursor-pointer"
                />
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="p-4 bg-neutral-900/40 rounded-2xl border border-neutral-800 text-center text-xs text-neutral-400">
          Toggle switch above to automatically isolate photo subject &amp; swap backgrounds.
        </div>
      )}
    </div>
  );
};
