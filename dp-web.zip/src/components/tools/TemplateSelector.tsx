import React from 'react';
import { PRESET_TEMPLATES } from '../../data/presetData';
import { DPTemplate } from '../../types';
import { Sparkles, Check } from 'lucide-react';

interface TemplateSelectorProps {
  onSelectTemplate: (template: DPTemplate) => void;
  activeTemplateId?: string;
}

export const TemplateSelector: React.FC<TemplateSelectorProps> = ({
  onSelectTemplate,
  activeTemplateId,
}) => {
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-bold text-neutral-200 flex items-center gap-1.5 uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
          Professional DP Templates
        </h3>
        <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full font-medium">
          1-Click Applied
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-[260px] overflow-y-auto pr-1">
        {PRESET_TEMPLATES.map((tmpl) => {
          const isSelected = activeTemplateId === tmpl.id;
          return (
            <button
              key={tmpl.id}
              onClick={() => onSelectTemplate(tmpl)}
              className={`p-3 rounded-2xl border text-left transition-all relative group cursor-pointer active:scale-95 ${
                isSelected
                  ? 'bg-emerald-500/15 border-emerald-500 text-emerald-300 ring-2 ring-emerald-500/20'
                  : 'bg-neutral-900 border-neutral-800 hover:border-neutral-700 text-neutral-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold truncate">{tmpl.name}</span>
                {isSelected && <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
              </div>
              <p className="text-[10px] text-neutral-400 font-medium">{tmpl.category}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
};
