import React from 'react';
import { BgState } from '../../types';
import { Droplet, Sparkles } from 'lucide-react';

interface BlurToolProps {
  bgState: BgState;
  setBgState: React.Dispatch<React.SetStateAction<BgState>>;
}

export const BlurTool: React.FC<BlurToolProps> = ({ bgState, setBgState }) => {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-bold text-neutral-200 flex items-center gap-1.5 uppercase tracking-wider">
          <Droplet className="w-3.5 h-3.5 text-emerald-400" />
          AI Background Blur &amp; Bokeh
        </h3>
        <span className="font-mono text-emerald-400 text-xs font-bold">
          {bgState.blurBackground}px
        </span>
      </div>

      <div className="space-y-3 bg-neutral-900/60 p-3.5 rounded-2xl border border-neutral-800">
        <div>
          <div className="flex items-center justify-between text-[11px] text-neutral-400 mb-1">
            <span>Background Blur Intensity</span>
            <span className="font-mono text-neutral-200">{bgState.blurBackground}px</span>
          </div>
          <input
            type="range"
            min="0"
            max="30"
            value={bgState.blurBackground}
            onChange={(e) =>
              setBgState((prev) => ({ ...prev, blurBackground: Number(e.target.value) }))
            }
            className="w-full accent-emerald-500 cursor-pointer"
          />
        </div>

        <p className="text-[11px] text-neutral-400 leading-relaxed pt-1">
          Applies depth-of-field DSLR lens blur to the background layer keeping subject crisp in focus.
        </p>
      </div>
    </div>
  );
};
