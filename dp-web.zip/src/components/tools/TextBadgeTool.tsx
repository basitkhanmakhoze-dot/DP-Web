import React, { useState } from 'react';
import { BadgeOption, TextOverlay } from '../../types';
import { PRESET_BADGES, FONT_LIST } from '../../data/presetData';
import { BadgeCheck, Type, Plus, Trash2, CheckCircle2 } from 'lucide-react';

interface TextBadgeToolProps {
  badge: BadgeOption;
  setBadge: React.Dispatch<React.SetStateAction<BadgeOption>>;
  textOverlays: TextOverlay[];
  setTextOverlays: React.Dispatch<React.SetStateAction<TextOverlay[]>>;
}

export const TextBadgeTool: React.FC<TextBadgeToolProps> = ({
  badge,
  setBadge,
  textOverlays,
  setTextOverlays,
}) => {
  const [newText, setNewText] = useState<string>('CREATOR');

  const handleAddText = () => {
    if (!newText.trim()) return;
    const newItem: TextOverlay = {
      id: `txt-${Date.now()}`,
      text: newText.trim(),
      fontFamily: FONT_LIST[0].value,
      fontSize: 28,
      color: '#FFFFFF',
      bgColor: '#10B981',
      isCurved: false,
      hasShadow: true,
      hasOutline: false,
      outlineColor: '#000000',
      positionY: 85,
    };
    setTextOverlays((prev) => [...prev, newItem]);
    setNewText('');
  };

  const handleRemoveText = (id: string) => {
    setTextOverlays((prev) => prev.filter((t) => t.id !== id));
  };

  return (
    <div className="space-y-4">
      {/* Verification Badges */}
      <div>
        <h3 className="text-xs font-bold text-neutral-200 flex items-center gap-1.5 uppercase tracking-wider mb-2.5">
          <BadgeCheck className="w-3.5 h-3.5 text-emerald-400" />
          Verification Checkmarks &amp; Badges
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 max-h-[180px] overflow-y-auto pr-1">
          {PRESET_BADGES.map((b) => {
            const isSelected = badge.id === b.id;
            return (
              <button
                key={b.id}
                onClick={() => setBadge(b)}
                className={`p-2.5 rounded-2xl border text-xs font-bold text-left transition-all cursor-pointer active:scale-95 ${
                  isSelected
                    ? 'bg-emerald-500 text-neutral-950 border-emerald-500 shadow-sm'
                    : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:border-neutral-700'
                }`}
              >
                {b.name}
              </button>
            );
          })}
        </div>
      </div>

      {/* Custom Text Overlays */}
      <div className="pt-2 border-t border-neutral-800">
        <h3 className="text-xs font-bold text-neutral-200 flex items-center gap-1.5 uppercase tracking-wider mb-2.5">
          <Type className="w-3.5 h-3.5 text-emerald-400" />
          Custom Text &amp; Status Labels
        </h3>

        <div className="flex gap-2 mb-3">
          <input
            type="text"
            placeholder="Add status e.g. 'OPEN TO WORK' or name..."
            value={newText}
            onChange={(e) => setNewText(e.target.value)}
            className="flex-1 px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-100 text-xs focus:outline-none focus:border-emerald-500"
          />
          <button
            onClick={handleAddText}
            className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs flex items-center gap-1 cursor-pointer active:scale-95 shrink-0"
          >
            <Plus className="w-3.5 h-3.5" /> Add Text
          </button>
        </div>

        {textOverlays.length > 0 && (
          <div className="space-y-3">
            {textOverlays.map((t, idx) => (
              <div
                key={t.id}
                className="bg-neutral-900/60 p-3 rounded-2xl border border-neutral-800 space-y-2.5"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-400">Text #{idx + 1}</span>
                  <button
                    onClick={() => handleRemoveText(t.id)}
                    className="text-red-400 hover:text-red-300 p-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <input
                  type="text"
                  value={t.text}
                  onChange={(e) => {
                    const val = e.target.value;
                    setTextOverlays((prev) =>
                      prev.map((item) => (item.id === t.id ? { ...item, text: val } : item))
                    );
                  }}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-neutral-800 border border-neutral-700 text-xs text-neutral-100"
                />

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-neutral-400 mb-1 block">Font Family</label>
                    <select
                      value={t.fontFamily}
                      onChange={(e) => {
                        const val = e.target.value;
                        setTextOverlays((prev) =>
                          prev.map((item) => (item.id === t.id ? { ...item, fontFamily: val } : item))
                        );
                      }}
                      className="w-full px-2 py-1 rounded-lg bg-neutral-800 text-xs text-neutral-200 border border-neutral-700"
                    >
                      {FONT_LIST.map((f) => (
                        <option key={f.name} value={f.value}>
                          {f.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] text-neutral-400 mb-1 block">Font Size ({t.fontSize})</label>
                    <input
                      type="range"
                      min="14"
                      max="60"
                      value={t.fontSize}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        setTextOverlays((prev) =>
                          prev.map((item) => (item.id === t.id ? { ...item, fontSize: val } : item))
                        );
                      }}
                      className="w-full accent-emerald-500 cursor-pointer"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between text-[10px] text-neutral-400 mb-1">
                    <span>Vertical Position Y ({t.positionY}%)</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="90"
                    value={t.positionY}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setTextOverlays((prev) =>
                        prev.map((item) => (item.id === t.id ? { ...item, positionY: val } : item))
                      );
                    }}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
