import React, { useState, useEffect } from 'react';
import { CompressionSettings } from '../../types';
import { compressCanvas } from '../../utils/canvasUtils';
import { HardDrive, Download, Zap, CheckCircle2 } from 'lucide-react';

interface CompressorToolProps {
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
}

export const CompressorTool: React.FC<CompressorToolProps> = ({ canvasRef }) => {
  const [quality, setQuality] = useState<number>(80);
  const [format, setFormat] = useState<'image/jpeg' | 'image/png' | 'image/webp'>('image/jpeg');
  const [compressedData, setCompressedData] = useState<{
    sizeKB: number;
    dataUrl: string;
    blob: Blob | null;
  }>({ sizeKB: 0, dataUrl: '', blob: null });

  useEffect(() => {
    if (!canvasRef.current) return;

    compressCanvas(canvasRef.current, quality / 100, format).then((res) => {
      setCompressedData({
        sizeKB: res.sizeKB,
        dataUrl: res.dataUrl,
        blob: res.blob,
      });
    });
  }, [quality, format, canvasRef]);

  const handleDownloadCompressed = () => {
    if (!compressedData.dataUrl) return;
    const a = document.createElement('a');
    a.href = compressedData.dataUrl;
    a.download = `DP_Web_Compressed_${quality}pct.${format.split('/')[1]}`;
    a.click();
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-bold text-neutral-200 flex items-center gap-1.5 uppercase tracking-wider">
          <HardDrive className="w-3.5 h-3.5 text-emerald-400" />
          Image Compressor (File Size Reducer)
        </h3>
        <span className="text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full font-mono">
          {compressedData.sizeKB} KB
        </span>
      </div>

      <div className="space-y-3 bg-neutral-900/60 p-3.5 rounded-2xl border border-neutral-800">
        <div>
          <div className="flex items-center justify-between text-[11px] text-neutral-400 mb-1">
            <span>Compression Quality Level</span>
            <span className="font-mono text-neutral-200">{quality}%</span>
          </div>
          <input
            type="range"
            min="10"
            max="100"
            value={quality}
            onChange={(e) => setQuality(Number(e.target.value))}
            className="w-full accent-emerald-500 cursor-pointer"
          />
        </div>

        <div>
          <label className="text-[11px] text-neutral-400 font-semibold mb-1 block">
            Compression Format
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'image/jpeg', name: 'JPEG (Compact)' },
              { id: 'image/webp', name: 'WebP (NextGen)' },
              { id: 'image/png', name: 'PNG (Lossless)' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setFormat(f.id as any)}
                className={`p-2 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                  format === f.id
                    ? 'bg-emerald-500 text-neutral-950 border-emerald-500'
                    : 'bg-neutral-800 text-neutral-300 border-neutral-700'
                }`}
              >
                {f.name}
              </button>
            ))}
          </div>
        </div>

        {/* Compression Estimation Card */}
        <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 flex items-center justify-between">
          <div>
            <p className="text-[10px] text-neutral-400 uppercase font-semibold">Estimated Size</p>
            <p className="text-sm font-extrabold text-emerald-400 font-mono">
              ~{compressedData.sizeKB} KB
            </p>
          </div>
          <button
            onClick={handleDownloadCompressed}
            className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer active:scale-95 shadow-md shadow-emerald-500/20"
          >
            <Download className="w-3.5 h-3.5" /> Download Compressed
          </button>
        </div>
      </div>
    </div>
  );
};
