import React, { useState } from 'react';
import { Download, Share2, Check, X, ShieldCheck, MessageCircle, Instagram, Facebook, Linkedin, Copy } from 'lucide-react';

interface ExportShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
}

export const ExportShareModal: React.FC<ExportShareModalProps> = ({
  isOpen,
  onClose,
  canvasRef,
}) => {
  const [resolution, setResolution] = useState<number>(1080);
  const [format, setFormat] = useState<'png' | 'jpeg' | 'webp'>('png');
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleDownload = () => {
    if (!canvasRef.current) return;

    // Create high-resolution export canvas
    const exportCanvas = document.createElement('canvas');
    exportCanvas.width = resolution;
    exportCanvas.height = resolution;
    const ctx = exportCanvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(canvasRef.current, 0, 0, resolution, resolution);

    const mimeType = format === 'png' ? 'image/png' : format === 'webp' ? 'image/webp' : 'image/jpeg';
    const dataUrl = exportCanvas.toDataURL(mimeType, 0.95);

    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `DP_Web_HD_Profile_${resolution}p.${format}`;
    a.click();
  };

  const handleWebShare = async () => {
    if (!canvasRef.current) return;
    try {
      canvasRef.current.toBlob(async (blob) => {
        if (!blob) return;
        const file = new File([blob], 'DP_Web_Profile.png', { type: 'image/png' });
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          await navigator.share({
            files: [file],
            title: 'My Display Picture — DP Web',
            text: 'Created with DP Web — Professional Display Picture Editor!',
          });
        } else {
          // Fallback to copying image URL or showing alert
          handleDownload();
        }
      });
    } catch (err) {
      console.log('Web Share Error:', err);
      handleDownload();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-neutral-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl max-w-md w-full p-6 shadow-2xl text-neutral-100 relative space-y-5 animate-in fade-in zoom-in-95 duration-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <Download className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold">Export in HD &amp; Share</h2>
            <p className="text-xs text-neutral-400">Save in high definition or share directly</p>
          </div>
        </div>

        {/* Export Quality / Resolution Selector */}
        <div className="space-y-3">
          <label className="text-xs font-semibold text-neutral-300 block">
            Resolution &amp; Quality
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { res: 800, label: 'Standard', detail: '800 x 800' },
              { res: 1080, label: 'HD Quality', detail: '1080 x 1080' },
              { res: 2048, label: 'Ultra 4K HD', detail: '2048 x 2048' },
            ].map((item) => (
              <button
                key={item.res}
                onClick={() => setResolution(item.res)}
                className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                  resolution === item.res
                    ? 'bg-emerald-500/15 border-emerald-500 text-emerald-300'
                    : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                }`}
              >
                <p className="text-xs font-bold text-neutral-100">{item.label}</p>
                <p className="text-[10px] text-neutral-400 font-mono mt-0.5">{item.detail}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Format Selector */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-neutral-300 block">
            File Format
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'png', name: 'PNG (Crystal Clear)' },
              { id: 'jpeg', name: 'JPEG (High Quality)' },
              { id: 'webp', name: 'WebP (Fast Web)' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setFormat(f.id as any)}
                className={`p-2 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                  format === f.id
                    ? 'bg-emerald-500 text-neutral-950 border-emerald-500'
                    : 'bg-neutral-950 text-neutral-300 border-neutral-800'
                }`}
              >
                {f.name}
              </button>
            ))}
          </div>
        </div>

        {/* Download & Share Trigger Buttons */}
        <div className="space-y-2.5 pt-2">
          <button
            onClick={handleDownload}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-neutral-950 font-bold text-sm shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Download HD Display Picture</span>
          </button>

          <button
            onClick={handleWebShare}
            className="w-full py-3 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-neutral-100 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
          >
            <Share2 className="w-4 h-4 text-emerald-400" />
            <span>Share directly to WhatsApp / Apps</span>
          </button>
        </div>

        {/* Social Direct Guides */}
        <div className="p-3 bg-neutral-950 rounded-2xl border border-neutral-800 text-[11px] text-neutral-400 space-y-1">
          <p className="font-semibold text-neutral-300 flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> WhatsApp &amp; Social Media Ready
          </p>
          <p>Saved at 1:1 square ratio formatted to prevent awkward cropping when uploading as DP.</p>
        </div>
      </div>
    </div>
  );
};
