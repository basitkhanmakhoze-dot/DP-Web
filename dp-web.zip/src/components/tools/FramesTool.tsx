import React from 'react';
import { FrameOption } from '../../types';
import { PRESET_FRAMES } from '../../data/presetData';
import { Circle, Sparkles } from 'lucide-react';

interface FramesToolProps {
  frame: FrameOption;
  setFrame: React.Dispatch<React.SetStateAction<FrameOption>>;
}

export const FramesTool: React.FC<FramesToolProps> = ({ frame, setFrame }) => {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-bold text-neutral-200 flex items-center gap-1.5 uppercase tracking-wider">
          <Circle className="w-3.5 h-3.5 text-emerald-400" />
          Frames &amp; Profile Rings
        </h3>
        <span className="text-[10px] text-emerald-400 font-semibold bg-emerald-500/10 px-2 py-0.5 rounded-full">
          {frame.name}
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 max-h-[220px] overflow-y-auto pr-1">
        {PRESET_FRAMES.map((f) => {
          const isSelected = frame.id === f.id;
          return (
            <button
              key={f.id}
              onClick={() => setFrame(f)}
              className={`p-3 rounded-2xl border text-xs font-bold text-left transition-all cursor-pointer active:scale-95 ${
                isSelected
                  ? 'bg-emerald-500 text-neutral-950 border-emerald-500 shadow-sm'
                  : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:border-neutral-700'
              }`}
            >
              {f.name}
            </button>
          );
        })}
      </div>

      {frame.type !== 'none' && (
        <div className="space-y-3 bg-neutral-900/60 p-3.5 rounded-2xl border border-neutral-800">
          <div>
            <div className="flex items-center justify-between text-[11px] text-neutral-400 mb-1">
              <span>Ring Border Width</span>
              <span className="font-mono text-neutral-200">{frame.width}px</span>
            </div>
            <input
              type="range"
              min="2"
              max="24"
              value={frame.width}
              onChange={(e) =>
                setFrame((prev) => ({ ...prev, width: Number(e.target.value) }))
              }
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex items-center justify-between text-[11px] text-neutral-400 mb-1">
              <span>Ring Inset Distance</span>
              <span className="font-mono text-neutral-200">{frame.inset}px</span>
            </div>
            <input
              type="range"
              min="0"
              max="35"
              value={frame.inset}
              onChange={(e) =>
                setFrame((prev) => ({ ...prev, inset: Number(e.target.value) }))
              }
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          <div>
            <label className="text-[11px] text-neutral-400 font-semibold mb-1 block">
              Ring Custom Color
            </label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={frame.color1 || '#10B981'}
                onChange={(e) =>
                  setFrame((prev) => ({ ...prev, color1: e.target.value }))
                }
                className="w-8 h-8 rounded-lg bg-neutral-800 border border-neutral-700 cursor-pointer"
              />
              <span className="text-xs font-mono text-neutral-300">{frame.color1}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
