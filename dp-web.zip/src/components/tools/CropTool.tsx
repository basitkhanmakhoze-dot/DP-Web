import React from 'react';
import { CropState, AspectRatioType } from '../../types';
import { Crop, RotateCw, RotateCcw, FlipHorizontal, FlipVertical, ZoomIn, Move } from 'lucide-react';

interface CropToolProps {
  cropState: CropState;
  setCropState: React.Dispatch<React.SetStateAction<CropState>>;
}

export const CropTool: React.FC<CropToolProps> = ({ cropState, setCropState }) => {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-bold text-neutral-200 flex items-center gap-1.5 uppercase tracking-wider">
          <Crop className="w-3.5 h-3.5 text-emerald-400" />
          Circle &amp; Square Crop
        </h3>
        <button
          onClick={() =>
            setCropState({
              aspectRatio: '1:1',
              scale: 1,
              rotation: 0,
              offsetX: 0,
              offsetY: 0,
              flipH: false,
              flipV: false,
            })
          }
          className="text-[11px] text-emerald-400 hover:underline font-semibold"
        >
          Reset Crop
        </button>
      </div>

      {/* Aspect Ratio Buttons */}
      <div>
        <label className="text-[11px] text-neutral-400 font-semibold mb-1.5 block">
          Crop Shape &amp; Aspect Ratio
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {[
            { id: '1:1', name: 'Square (1:1)' },
            { id: 'circle', name: 'Circle Profile' },
            { id: '9:16', name: 'Story (9:16)' },
            { id: '16:9', name: 'Banner (16:9)' },
          ].map((r) => (
            <button
              key={r.id}
              onClick={() =>
                setCropState((prev) => ({ ...prev, aspectRatio: r.id as AspectRatioType }))
              }
              className={`p-2.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                cropState.aspectRatio === r.id
                  ? 'bg-emerald-500 text-neutral-950 border-emerald-500 shadow-sm'
                  : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:border-neutral-700'
              }`}
            >
              {r.name}
            </button>
          ))}
        </div>
      </div>

      {/* Controls Sliders */}
      <div className="space-y-3 bg-neutral-900/60 p-3.5 rounded-2xl border border-neutral-800">
        <div>
          <div className="flex items-center justify-between text-[11px] text-neutral-400 mb-1">
            <span className="flex items-center gap-1"><ZoomIn className="w-3 h-3 text-emerald-400" /> Scale / Zoom</span>
            <span className="font-mono text-neutral-200">{Math.round(cropState.scale * 100)}%</span>
          </div>
          <input
            type="range"
            min="0.5"
            max="3"
            step="0.05"
            value={cropState.scale}
            onChange={(e) =>
              setCropState((prev) => ({ ...prev, scale: Number(e.target.value) }))
            }
            className="w-full accent-emerald-500 cursor-pointer"
          />
        </div>

        <div>
          <div className="flex items-center justify-between text-[11px] text-neutral-400 mb-1">
            <span className="flex items-center gap-1"><RotateCw className="w-3 h-3 text-emerald-400" /> Rotation Angle</span>
            <span className="font-mono text-neutral-200">{cropState.rotation}°</span>
          </div>
          <input
            type="range"
            min="-180"
            max="180"
            value={cropState.rotation}
            onChange={(e) =>
              setCropState((prev) => ({ ...prev, rotation: Number(e.target.value) }))
            }
            className="w-full accent-emerald-500 cursor-pointer"
          />
        </div>

        {/* Quick Flip & Rotate Actions */}
        <div className="flex items-center gap-2 pt-1">
          <button
            onClick={() =>
              setCropState((prev) => ({ ...prev, rotation: (prev.rotation + 90) % 360 }))
            }
            className="flex-1 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <RotateCw className="w-3.5 h-3.5" /> Rotate 90°
          </button>

          <button
            onClick={() => setCropState((prev) => ({ ...prev, flipH: !prev.flipH }))}
            className={`flex-1 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              cropState.flipH ? 'bg-emerald-500 text-neutral-950' : 'bg-neutral-800 text-neutral-200 hover:bg-neutral-700'
            }`}
          >
            <FlipHorizontal className="w-3.5 h-3.5" /> Flip Horiz
          </button>

          <button
            onClick={() => setCropState((prev) => ({ ...prev, flipV: !prev.flipV }))}
            className={`flex-1 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              cropState.flipV ? 'bg-emerald-500 text-neutral-950' : 'bg-neutral-800 text-neutral-200 hover:bg-neutral-700'
            }`}
          >
            <FlipVertical className="w-3.5 h-3.5" /> Flip Vert
          </button>
        </div>

        {/* Position Pan Offset Sliders */}
        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-neutral-800">
          <div>
            <div className="flex items-center justify-between text-[10px] text-neutral-400 mb-1">
              <span>Pan Position X</span>
              <span className="font-mono text-neutral-200">{cropState.offsetX}</span>
            </div>
            <input
              type="range"
              min="-150"
              max="150"
              value={cropState.offsetX}
              onChange={(e) =>
                setCropState((prev) => ({ ...prev, offsetX: Number(e.target.value) }))
              }
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex items-center justify-between text-[10px] text-neutral-400 mb-1">
              <span>Pan Position Y</span>
              <span className="font-mono text-neutral-200">{cropState.offsetY}</span>
            </div>
            <input
              type="range"
              min="-150"
              max="150"
              value={cropState.offsetY}
              onChange={(e) =>
                setCropState((prev) => ({ ...prev, offsetY: Number(e.target.value) }))
              }
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
