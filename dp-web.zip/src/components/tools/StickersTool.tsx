import React from 'react';
import { StickerOverlay } from '../../types';
import { STICKER_PACK } from '../../data/presetData';
import { Smile, Trash2, Plus } from 'lucide-react';

interface StickersToolProps {
  stickers: StickerOverlay[];
  setStickers: React.Dispatch<React.SetStateAction<StickerOverlay[]>>;
}

export const StickersTool: React.FC<StickersToolProps> = ({ stickers, setStickers }) => {
  const handleAddSticker = (emoji: string) => {
    const newSticker: StickerOverlay = {
      id: `stk-${Date.now()}`,
      emojiOrUrl: emoji,
      x: 82,
      y: 18,
      size: 48,
      rotation: 0,
    };
    setStickers((prev) => [...prev, newSticker]);
  };

  const handleRemoveSticker = (id: string) => {
    setStickers((prev) => prev.filter((s) => s.id !== id));
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-bold text-neutral-200 flex items-center gap-1.5 uppercase tracking-wider">
          <Smile className="w-3.5 h-3.5 text-emerald-400" />
          Stickers &amp; Emojis
        </h3>
        {stickers.length > 0 && (
          <button
            onClick={() => setStickers([])}
            className="text-[10px] text-red-400 hover:underline font-semibold"
          >
            Clear All
          </button>
        )}
      </div>

      <div className="grid grid-cols-5 sm:grid-cols-10 gap-2 bg-neutral-900/60 p-3 rounded-2xl border border-neutral-800">
        {STICKER_PACK.map((stk) => (
          <button
            key={stk}
            onClick={() => handleAddSticker(stk)}
            className="w-9 h-9 rounded-xl bg-neutral-800 hover:bg-neutral-700 hover:scale-110 text-lg flex items-center justify-center transition-all cursor-pointer active:scale-95"
            title="Click to add sticker"
          >
            {stk}
          </button>
        ))}
      </div>

      {stickers.length > 0 && (
        <div className="space-y-3">
          <label className="text-[11px] text-neutral-400 font-semibold block">
            Active Stickers ({stickers.length})
          </label>
          {stickers.map((s, idx) => (
            <div
              key={s.id}
              className="bg-neutral-900 p-3 rounded-2xl border border-neutral-800 space-y-2"
            >
              <div className="flex items-center justify-between">
                <span className="text-base">{s.emojiOrUrl} Sticker</span>
                <button
                  onClick={() => handleRemoveSticker(s.id)}
                  className="text-red-400 hover:text-red-300 p-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-neutral-400">Size ({s.size}px)</label>
                  <input
                    type="range"
                    min="20"
                    max="100"
                    value={s.size}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setStickers((prev) =>
                        prev.map((item) => (item.id === s.id ? { ...item, size: val } : item))
                      );
                    }}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-neutral-400">Rotation ({s.rotation}°)</label>
                  <input
                    type="range"
                    min="-180"
                    max="180"
                    value={s.rotation}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setStickers((prev) =>
                        prev.map((item) => (item.id === s.id ? { ...item, rotation: val } : item))
                      );
                    }}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
