import React from 'react';
import { ImageAdjustments, FilterPresetType } from '../../types';
import { Sparkles, Sliders, Sun, Contrast, Droplet, Zap } from 'lucide-react';

interface EnhancerToolProps {
  adjustments: ImageAdjustments;
  setAdjustments: React.Dispatch<React.SetStateAction<ImageAdjustments>>;
}

export const EnhancerTool: React.FC<EnhancerToolProps> = ({
  adjustments,
  setAdjustments,
}) => {
  const applyPreset = (preset: FilterPresetType) => {
    switch (preset) {
      case 'auto-hd':
        setAdjustments({
          brightness: 8,
          contrast: 15,
          saturation: 10,
          sharpen: 30,
          vibrance: 12,
          warmth: 0,
          skinGlow: 15,
          blurBg: adjustments.blurBg,
        });
        break;
      case 'portrait-glow':
        setAdjustments({
          brightness: 12,
          contrast: 8,
          saturation: 5,
          sharpen: 15,
          vibrance: 5,
          warmth: 10,
          skinGlow: 35,
          blurBg: adjustments.blurBg,
        });
        break;
      case 'warm-studio':
        setAdjustments({
          brightness: 5,
          contrast: 12,
          saturation: 8,
          sharpen: 20,
          vibrance: 8,
          warmth: 20,
          skinGlow: 20,
          blurBg: adjustments.blurBg,
        });
        break;
      case 'cyber-emerald':
        setAdjustments({
          brightness: 5,
          contrast: 25,
          saturation: 20,
          sharpen: 35,
          vibrance: 25,
          warmth: -15,
          skinGlow: 10,
          blurBg: adjustments.blurBg,
        });
        break;
      case 'bw-dramatic':
        setAdjustments({
          brightness: 0,
          contrast: 35,
          saturation: -100,
          sharpen: 40,
          vibrance: -100,
          warmth: 0,
          skinGlow: 0,
          blurBg: adjustments.blurBg,
        });
        break;
      case 'normal':
      default:
        setAdjustments({
          brightness: 0,
          contrast: 0,
          saturation: 0,
          sharpen: 0,
          vibrance: 0,
          warmth: 0,
          skinGlow: 0,
          blurBg: adjustments.blurBg,
        });
        break;
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-bold text-neutral-200 flex items-center gap-1.5 uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
          AI Photo Enhancer (HD Quality)
        </h3>
        <button
          onClick={() => applyPreset('auto-hd')}
          className="px-2.5 py-1 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-neutral-950 text-[11px] font-bold shadow-md shadow-emerald-500/20 flex items-center gap-1 cursor-pointer active:scale-95"
        >
          <Zap className="w-3 h-3" /> Auto AI HD
        </button>
      </div>

      <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-[11px] text-emerald-300 flex items-start gap-2 leading-relaxed">
        <Zap className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
        <span>
          <strong>Natural AI Clarity Engine:</strong> Edge-preserving unsharp masking enhances facial details, eyes, and hair crispness while maintaining natural skin texture.
        </span>
      </div>

      {/* Preset Filters Grid */}
      <div>
        <label className="text-[11px] text-neutral-400 font-semibold mb-1.5 block">
          One-Touch Filter Presets
        </label>
        <div className="grid grid-cols-3 gap-2">
          {[
            { id: 'normal', name: 'Original' },
            { id: 'auto-hd', name: 'Auto HD Clarity' },
            { id: 'portrait-glow', name: 'Portrait Glow' },
            { id: 'warm-studio', name: 'Warm Studio' },
            { id: 'cyber-emerald', name: 'Cyber Mint' },
            { id: 'bw-dramatic', name: 'B&W Dramatic' },
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => applyPreset(f.id as FilterPresetType)}
              className="px-2.5 py-2 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-emerald-500/50 text-neutral-200 text-xs font-medium text-center transition-all cursor-pointer active:scale-95"
            >
              {f.name}
            </button>
          ))}
        </div>
      </div>

      {/* Fine-Tuning Sliders */}
      <div className="space-y-3 bg-neutral-900/60 p-3.5 rounded-2xl border border-neutral-800">
        <div>
          <div className="flex items-center justify-between text-[11px] text-neutral-400 mb-1">
            <span className="flex items-center gap-1"><Sun className="w-3 h-3 text-emerald-400" /> Brightness</span>
            <span className="font-mono text-neutral-200">{adjustments.brightness}</span>
          </div>
          <input
            type="range"
            min="-50"
            max="50"
            value={adjustments.brightness}
            onChange={(e) =>
              setAdjustments((prev) => ({ ...prev, brightness: Number(e.target.value) }))
            }
            className="w-full accent-emerald-500 cursor-pointer"
          />
        </div>

        <div>
          <div className="flex items-center justify-between text-[11px] text-neutral-400 mb-1">
            <span className="flex items-center gap-1"><Contrast className="w-3 h-3 text-emerald-400" /> Contrast</span>
            <span className="font-mono text-neutral-200">{adjustments.contrast}</span>
          </div>
          <input
            type="range"
            min="-50"
            max="50"
            value={adjustments.contrast}
            onChange={(e) =>
              setAdjustments((prev) => ({ ...prev, contrast: Number(e.target.value) }))
            }
            className="w-full accent-emerald-500 cursor-pointer"
          />
        </div>

        <div>
          <div className="flex items-center justify-between text-[11px] text-neutral-400 mb-1">
            <span className="flex items-center gap-1"><Zap className="w-3 h-3 text-emerald-400" /> Sharpen &amp; HD Detail</span>
            <span className="font-mono text-neutral-200">{adjustments.sharpen}</span>
          </div>
          <input
            type="range"
            min="0"
            max="80"
            value={adjustments.sharpen}
            onChange={(e) =>
              setAdjustments((prev) => ({ ...prev, sharpen: Number(e.target.value) }))
            }
            className="w-full accent-emerald-500 cursor-pointer"
          />
        </div>

        <div>
          <div className="flex items-center justify-between text-[11px] text-neutral-400 mb-1">
            <span className="flex items-center gap-1"><Droplet className="w-3 h-3 text-emerald-400" /> Saturation</span>
            <span className="font-mono text-neutral-200">{adjustments.saturation}</span>
          </div>
          <input
            type="range"
            min="-100"
            max="50"
            value={adjustments.saturation}
            onChange={(e) =>
              setAdjustments((prev) => ({ ...prev, saturation: Number(e.target.value) }))
            }
            className="w-full accent-emerald-500 cursor-pointer"
          />
        </div>

        <div>
          <div className="flex items-center justify-between text-[11px] text-neutral-400 mb-1">
            <span>Skin Glow &amp; Soft Light</span>
            <span className="font-mono text-neutral-200">{adjustments.skinGlow}</span>
          </div>
          <input
            type="range"
            min="0"
            max="60"
            value={adjustments.skinGlow}
            onChange={(e) =>
              setAdjustments((prev) => ({ ...prev, skinGlow: Number(e.target.value) }))
            }
            className="w-full accent-emerald-500 cursor-pointer"
          />
        </div>
      </div>
    </div>
  );
};
