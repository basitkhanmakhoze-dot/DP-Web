import React, { useState } from 'react';
import { BgState, BgType } from '../../types';
import {
  PRESET_GRADIENTS,
  PRESET_SOLID_COLORS,
  AI_BG_SUGGESTIONS,
  PRESET_HD_BACKGROUNDS,
  HdBgPreset,
} from '../../data/presetData';
import {
  Sparkles,
  Palette,
  Upload,
  Image as ImageIcon,
  CheckCircle2,
  RefreshCw,
  Search,
  Wand2,
  Sliders,
  Layers,
} from 'lucide-react';

interface BgChangerToolProps {
  bgState: BgState;
  setBgState: React.Dispatch<React.SetStateAction<BgState>>;
  onGenerateAiBg: (promptText: string) => void;
  onSelectHdBgPreset: (preset: HdBgPreset) => void;
  onUploadCustomBg: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export const BgChangerTool: React.FC<BgChangerToolProps> = ({
  bgState,
  setBgState,
  onGenerateAiBg,
  onSelectHdBgPreset,
  onUploadCustomBg,
}) => {
  const [promptInput, setPromptInput] = useState(
    bgState.aiBgPrompt || 'Luxury executive office with city view'
  );
  const [categoryFilter, setCategoryFilter] = useState<string>('All');

  const categories = [
    'All',
    'Nature',
    'Professional',
    'Sports',
    'National',
    'Spiritual',
    'Studio',
    'Events',
    'Urban',
    'Lifestyle',
  ];

  const filteredPresets =
    categoryFilter === 'All'
      ? PRESET_HD_BACKGROUNDS
      : PRESET_HD_BACKGROUNDS.filter((p) => p.category === categoryFilter);

  const handleChipClick = (suggestionPrompt: string) => {
    setPromptInput(suggestionPrompt);
    setBgState((prev) => ({ ...prev, type: 'ai', aiBgPrompt: suggestionPrompt }));
    onGenerateAiBg(suggestionPrompt);
  };

  const handleSubmitAiGeneration = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promptInput.trim()) return;
    setBgState((prev) => ({ ...prev, type: 'ai', aiBgPrompt: promptInput }));
    onGenerateAiBg(promptInput.trim());
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-bold text-neutral-200 flex items-center gap-1.5 uppercase tracking-wider">
          <Wand2 className="w-3.5 h-3.5 text-emerald-400" />
          AI Background Studio
        </h3>
        <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono uppercase font-bold">
          {bgState.type}
        </span>
      </div>

      {/* Main Mode Tabs */}
      <div className="grid grid-cols-5 gap-1 p-1 rounded-2xl bg-neutral-900 border border-neutral-800">
        {[
          { id: 'ai', label: 'AI Gen', icon: Sparkles },
          { id: 'gradient', label: 'Gradient', icon: Palette },
          { id: 'solid', label: 'Color', icon: Sliders },
          { id: 'pattern', label: 'Pattern', icon: Layers },
          { id: 'custom', label: 'Upload', icon: Upload },
        ].map((t) => {
          const Icon = t.icon;
          const isActive =
            bgState.type === t.id ||
            (t.id === 'ai' && (bgState.type === 'custom' || bgState.type === 'ai'));
          return (
            <button
              key={t.id}
              onClick={() => setBgState((prev) => ({ ...prev, type: t.id as BgType }))}
              className={`py-1.5 px-1 rounded-xl text-[11px] font-bold transition-all flex flex-col sm:flex-row items-center justify-center gap-1 cursor-pointer ${
                isActive
                  ? 'bg-emerald-500 text-neutral-950 shadow-md font-extrabold'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
              }`}
            >
              <Icon className="w-3.5 h-3.5 shrink-0" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {/* AI GENERATOR & 20+ HD PRESETS MODE */}
      {(bgState.type === 'ai' || bgState.type === 'custom') && (
        <div className="space-y-4">
          {/* AI Prompt Generator Card */}
          <div className="p-3.5 rounded-2xl bg-neutral-900/80 border border-emerald-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-emerald-400 flex items-center gap-1.5 uppercase tracking-wide">
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                Describe Your AI Background
              </span>
              <span className="text-[9px] text-neutral-400 font-mono">HD 1080×1080</span>
            </div>

            <form onSubmit={handleSubmitAiGeneration} className="space-y-2">
              <div className="relative">
                <textarea
                  rows={2}
                  value={promptInput}
                  onChange={(e) => setPromptInput(e.target.value)}
                  placeholder="e.g. mountains, luxury office, cricket stadium, Pakistan flag, Islamic mosque, blue studio, nature..."
                  className="w-full text-xs p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={bgState.aiBgLoading}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 disabled:opacity-50 text-neutral-950 font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/10 cursor-pointer active:scale-95 transition-all"
              >
                <Sparkles className={`w-4 h-4 ${bgState.aiBgLoading ? 'animate-spin' : ''}`} />
                <span>
                  {bgState.aiBgLoading
                    ? 'Generating HD Background...'
                    : 'Generate AI Background'}
                </span>
              </button>
            </form>

            {/* Clickable Suggestion Chips */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[10px] text-neutral-400 font-bold block uppercase tracking-wider">
                Quick Tap Prompt Suggestions:
              </span>
              <div className="flex flex-wrap gap-1.5 max-h-[110px] overflow-y-auto pr-1">
                {AI_BG_SUGGESTIONS.map((chip) => (
                  <button
                    key={chip.label}
                    onClick={() => handleChipClick(chip.prompt)}
                    className="px-2.5 py-1 rounded-full bg-neutral-800/80 hover:bg-emerald-500/20 hover:border-emerald-500/50 border border-neutral-700/80 text-[10px] font-semibold text-neutral-300 hover:text-emerald-300 transition-all flex items-center gap-1 cursor-pointer active:scale-95"
                  >
                    <span>{chip.emoji}</span>
                    <span>{chip.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 20+ HD Built-in Background Presets */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-neutral-200 flex items-center gap-1.5 uppercase tracking-wide">
                <ImageIcon className="w-3.5 h-3.5 text-emerald-400" />
                20+ Built-In HD Background Presets
              </span>
              <span className="text-[10px] text-emerald-400 font-mono font-bold">
                {PRESET_HD_BACKGROUNDS.length} Presets
              </span>
            </div>

            {/* Category Filter Pills */}
            <div className="flex gap-1 overflow-x-auto pb-1 text-[10px]">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategoryFilter(cat)}
                  className={`px-2.5 py-1 rounded-lg font-bold shrink-0 transition-all cursor-pointer ${
                    categoryFilter === cat
                      ? 'bg-emerald-500 text-neutral-950 shadow-sm'
                      : 'bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Presets Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-[260px] overflow-y-auto pr-1">
              {filteredPresets.map((preset) => {
                const isSelected = bgState.customBgUrl === preset.url;
                return (
                  <div
                    key={preset.id}
                    onClick={() => onSelectHdBgPreset(preset)}
                    className={`group relative h-24 rounded-xl overflow-hidden border cursor-pointer transition-all hover:scale-[1.02] active:scale-95 ${
                      isSelected
                        ? 'border-emerald-400 ring-2 ring-emerald-500/40'
                        : 'border-neutral-800 hover:border-neutral-700'
                    }`}
                  >
                    <img
                      src={preset.url}
                      alt={preset.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/90 via-neutral-950/30 to-transparent p-2 flex flex-col justify-end">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold text-white flex items-center gap-1 drop-shadow-md truncate">
                          <span>{preset.emoji}</span>
                          <span className="truncate">{preset.name}</span>
                        </span>
                        {isSelected && (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Gradients Selection */}
      {bgState.type === 'gradient' && (
        <div className="space-y-3">
          <label className="text-[11px] text-neutral-400 font-semibold block">
            Material 3 &amp; Modern Gradients
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 max-h-[220px] overflow-y-auto pr-1">
            {PRESET_GRADIENTS.map((g) => (
              <button
                key={g.name}
                onClick={() =>
                  setBgState((prev) => ({
                    ...prev,
                    type: 'gradient',
                    gradient: { color1: g.color1, color2: g.color2, angle: g.angle, type: 'linear' },
                  }))
                }
                className="h-12 rounded-xl border border-neutral-800 p-2 flex items-end justify-start text-[10px] font-bold text-white shadow-sm hover:scale-105 transition-all cursor-pointer active:scale-95"
                style={{
                  background: `linear-gradient(${g.angle}deg, ${g.color1}, ${g.color2})`,
                }}
              >
                <span className="bg-black/40 px-1.5 py-0.5 rounded backdrop-blur-sm truncate">
                  {g.name}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Solid Colors Selection */}
      {bgState.type === 'solid' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-[11px] text-neutral-400">
            <span>Color Palette</span>
            <input
              type="color"
              value={bgState.solidColor}
              onChange={(e) =>
                setBgState((prev) => ({ ...prev, solidColor: e.target.value }))
              }
              className="w-6 h-6 rounded-md bg-neutral-800 border border-neutral-700 cursor-pointer"
            />
          </div>
          <div className="grid grid-cols-6 sm:grid-cols-12 gap-1.5">
            {PRESET_SOLID_COLORS.map((c) => (
              <button
                key={c}
                onClick={() => setBgState((prev) => ({ ...prev, solidColor: c }))}
                className={`w-7 h-7 rounded-lg border transition-transform cursor-pointer active:scale-95 ${
                  bgState.solidColor === c
                    ? 'border-emerald-400 ring-2 ring-emerald-500/30 scale-110'
                    : 'border-neutral-700'
                }`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>
        </div>
      )}

      {/* Pattern Selection */}
      {bgState.type === 'pattern' && (
        <div className="space-y-2">
          <label className="text-[11px] text-neutral-400 font-semibold block">
            Aesthetic Patterns
          </label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'dots', name: 'Polka Dots' },
              { id: 'grid', name: 'Studio Grid' },
            ].map((p) => (
              <button
                key={p.id}
                onClick={() => setBgState((prev) => ({ ...prev, pattern: p.id }))}
                className={`p-3 rounded-2xl border text-xs font-bold transition-all cursor-pointer ${
                  bgState.pattern === p.id
                    ? 'bg-emerald-500 text-neutral-950 border-emerald-500'
                    : 'bg-neutral-900 border-neutral-800 text-neutral-300'
                }`}
              >
                {p.name}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Custom Upload Tab */}
      {bgState.type === 'custom' && (
        <div className="space-y-3">
          <label className="text-[11px] text-neutral-400 font-semibold block">
            Upload Custom Background Photo
          </label>
          <label className="p-4 rounded-2xl border-2 border-dashed border-neutral-800 hover:border-emerald-500/50 bg-neutral-900/60 flex flex-col items-center justify-center gap-2 cursor-pointer transition-all text-neutral-400 hover:text-emerald-400">
            <Upload className="w-5 h-5" />
            <span className="text-xs font-bold">Choose background image from computer</span>
            <input
              type="file"
              accept="image/*"
              onChange={onUploadCustomBg}
              className="hidden"
            />
          </label>
        </div>
      )}
    </div>
  );
};
