import React, { useState } from 'react';
import { Bot, Sparkles, X, Copy, Check, RefreshCw, Wand2, MessageSquare } from 'lucide-react';
import { DPTemplate } from '../../types';

interface GeminiAdviceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyStyleRecommendation?: (recommendation: any) => void;
}

export const GeminiAdviceModal: React.FC<GeminiAdviceModalProps> = ({
  isOpen,
  onClose,
  onApplyStyleRecommendation,
}) => {
  const [activeTab, setActiveTab] = useState<'style' | 'bio'>('style');

  // Style recommender form state
  const [profession, setProfession] = useState<string>('Software Engineer / Tech Founder');
  const [stylePreference, setStylePreference] = useState<string>('Modern Professional');
  const [platform, setPlatform] = useState<string>('LinkedIn & WhatsApp');
  const [styleLoading, setStyleLoading] = useState<boolean>(false);
  const [styleResult, setStyleResult] = useState<any>(null);

  // Bio generator form state
  const [category, setCategory] = useState<string>('WhatsApp & Instagram');
  const [tone, setTone] = useState<string>('Professional & Friendly');
  const [bioLoading, setBioLoading] = useState<boolean>(false);
  const [bios, setBios] = useState<string[]>([]);
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  if (!isOpen) return null;

  const handleFetchStyleAdvice = async () => {
    setStyleLoading(true);
    try {
      const res = await fetch('/api/gemini/suggest-style', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ profession, stylePreference, platform }),
      });
      const data = await res.json();
      if (data.success && data.recommendation) {
        setStyleResult(data.recommendation);
      }
    } catch (err) {
      console.error('Style recommendation error:', err);
    } finally {
      setStyleLoading(false);
    }
  };

  const handleFetchBios = async () => {
    setBioLoading(true);
    try {
      const res = await fetch('/api/gemini/generate-bio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ category, tone }),
      });
      const data = await res.json();
      if (data.success && Array.isArray(data.captions)) {
        setBios(data.captions);
      }
    } catch (err) {
      console.error('Bio generator error:', err);
    } finally {
      setBioLoading(false);
    }
  };

  const handleCopyBio = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-neutral-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl text-neutral-100 relative space-y-5 animate-in fade-in zoom-in-95 duration-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold">AI DP Assistant &amp; Bio Generator</h2>
            <p className="text-xs text-neutral-400">Powered by Gemini AI Studio</p>
          </div>
        </div>

        {/* Tab Toggle */}
        <div className="grid grid-cols-2 gap-1.5 p-1 rounded-2xl bg-neutral-950 border border-neutral-800">
          <button
            onClick={() => setActiveTab('style')}
            className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'style'
                ? 'bg-emerald-500 text-neutral-950 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Wand2 className="w-3.5 h-3.5" /> AI Style Advice
          </button>
          <button
            onClick={() => setActiveTab('bio')}
            className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'bio'
                ? 'bg-emerald-500 text-neutral-950 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" /> Bio &amp; Captions
          </button>
        </div>

        {/* Style Advice Tab */}
        {activeTab === 'style' && (
          <div className="space-y-4">
            <div className="space-y-2 text-xs">
              <div>
                <label className="text-[11px] font-semibold text-neutral-300 block mb-1">
                  Your Role / Profession
                </label>
                <input
                  type="text"
                  value={profession}
                  onChange={(e) => setProfession(e.target.value)}
                  placeholder="e.g. Graphic Designer, Student, Founder..."
                  className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-neutral-300 block mb-1">
                  Target Vibe
                </label>
                <select
                  value={stylePreference}
                  onChange={(e) => setStylePreference(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-100 focus:outline-none focus:border-emerald-500"
                >
                  <option value="Modern Professional">Modern Professional</option>
                  <option value="Creative & Artistic">Creative &amp; Artistic</option>
                  <option value="Executive Luxury">Executive Luxury</option>
                  <option value="Cyber / Tech Vibe">Cyber / Tech Vibe</option>
                  <option value="Aesthetic & Minimal">Aesthetic &amp; Minimal</option>
                </select>
              </div>
            </div>

            <button
              onClick={handleFetchStyleAdvice}
              disabled={styleLoading}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-neutral-950 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50"
            >
              {styleLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" /> Analyzing with Gemini...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" /> Get AI DP Recommendation
                </>
              )}
            </button>

            {styleResult && (
              <div className="p-4 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-2 text-xs text-neutral-300">
                <p className="font-bold text-emerald-400 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" /> AI Recommendation:
                </p>
                <p className="italic text-neutral-200">"{styleResult.dpAdvice}"</p>
                <div className="pt-2 border-t border-neutral-800 space-y-1 text-[11px]">
                  <p><span className="text-neutral-400">Recommended Badge:</span> {styleResult.recommendedBadge}</p>
                  <p><span className="text-neutral-400">Filter Preset:</span> {styleResult.filterPreset}</p>
                  <p><span className="text-neutral-400">Profile Quote:</span> {styleResult.bioCaption}</p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Bio Captions Tab */}
        {activeTab === 'bio' && (
          <div className="space-y-4">
            <div className="space-y-2 text-xs">
              <div>
                <label className="text-[11px] font-semibold text-neutral-300 block mb-1">
                  Social Platform
                </label>
                <input
                  type="text"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-neutral-300 block mb-1">
                  Tone &amp; Vibe
                </label>
                <input
                  type="text"
                  value={tone}
                  onChange={(e) => setTone(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-100 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <button
              onClick={handleFetchBios}
              disabled={bioLoading}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-neutral-950 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50"
            >
              {bioLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" /> Generating Captions...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" /> Generate Profile Captions
                </>
              )}
            </button>

            {bios.length > 0 && (
              <div className="space-y-2 max-h-[200px] overflow-y-auto pr-1">
                {bios.map((b, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 flex items-center justify-between gap-2 text-xs text-neutral-200"
                  >
                    <span>{b}</span>
                    <button
                      onClick={() => handleCopyBio(b, idx)}
                      className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-emerald-400 transition-colors shrink-0"
                    >
                      {copiedIdx === idx ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
