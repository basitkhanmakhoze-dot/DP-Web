import React from 'react';
import { SAMPLE_AVATARS } from '../../data/presetData';
import { SampleAvatar } from '../../types';
import { X, Image as ImageIcon, UserCheck } from 'lucide-react';

interface SampleAvatarsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectAvatar: (avatar: SampleAvatar) => void;
}

export const SampleAvatarsModal: React.FC<SampleAvatarsModalProps> = ({
  isOpen,
  onClose,
  onSelectAvatar,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-neutral-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl text-neutral-100 relative space-y-5 animate-in fade-in zoom-in-95 duration-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <ImageIcon className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold">Choose Sample Model Photo</h2>
            <p className="text-xs text-neutral-400">Test DP Web with high-resolution sample avatars</p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-[340px] overflow-y-auto pr-1">
          {SAMPLE_AVATARS.map((avatar) => (
            <button
              key={avatar.id}
              onClick={() => {
                onSelectAvatar(avatar);
                onClose();
              }}
              className="group relative rounded-2xl overflow-hidden border border-neutral-800 hover:border-emerald-500/50 bg-neutral-950 transition-all text-left cursor-pointer active:scale-95"
            >
              <div className="aspect-square w-full overflow-hidden">
                <img
                  src={avatar.url}
                  alt={avatar.name}
                  crossOrigin="anonymous"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              <div className="p-2.5 bg-neutral-900/90 backdrop-blur-sm border-t border-neutral-800">
                <p className="text-xs font-bold text-neutral-100 truncate">{avatar.name}</p>
                <p className="text-[10px] text-emerald-400 font-medium truncate">{avatar.role}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
