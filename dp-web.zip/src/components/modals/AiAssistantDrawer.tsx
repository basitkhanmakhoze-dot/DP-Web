import React, { useState, useRef, useEffect } from 'react';
import { Bot, Sparkles, X, Send, Wand2, ArrowRight, Zap, RefreshCw, MessageSquare, CheckCircle, ShieldCheck } from 'lucide-react';

export interface AssistantAction {
  label: string;
  actionType: 'switch_tab' | 'apply_preset' | 'apply_template' | 'select_frame' | 'select_badge';
  tab?: string;
  payload?: any;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  actions?: AssistantAction[];
  timestamp: string;
}

interface AiAssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentTab: string;
  hasImage: boolean;
  onPerformAssistantAction: (action: AssistantAction) => void;
}

const INITIAL_PROMPTS = [
  { label: '🇵🇰 Make Pakistan Flag DP', query: 'I want to create a Pakistan flag DP with my photo' },
  { label: '💼 Make my photo professional', query: 'How can I make my photo look professional for LinkedIn?' },
  { label: '🏔️ Change background to mountains', query: 'Change my background to scenic mountain view' },
  { label: '✨ Sharpen & improve face quality', query: 'How to improve face clarity and make my photo sharp HD?' },
  { label: '🟢 Add WhatsApp Green Ring & Verified Tick', query: 'Add a green ring around my photo and a verified tick badge' },
  { label: '🕌 Set Islamic Mosque backdrop', query: 'Set an elegant Islamic Mosque background' },
  { label: '🎨 Explain all features of DP Web', query: 'Explain all the features and tools available in DP Web' },
];

export const AiAssistantDrawer: React.FC<AiAssistantDrawerProps> = ({
  isOpen,
  onClose,
  currentTab,
  hasImage,
  onPerformAssistantAction,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: "👋 **Hello! I'm your AI Studio Assistant.**\n\nI can help you design a stunning profile picture, recommend editing tools, or automatically perform actions like changing backgrounds, sharpening faces, adding verified badges, or creating custom WhatsApp/LinkedIn DPs. What would you like to build today?",
      actions: [
        { label: '💼 Make Professional DP', actionType: 'switch_tab', tab: 'templates', payload: { templateId: 'linkedin-pro' } },
        { label: '🇵🇰 Pakistan Flag DP', actionType: 'apply_template', payload: { templateId: 'pakistan-patriot' } },
        { label: '✨ Auto AI HD Enhance', actionType: 'apply_preset', payload: { preset: 'auto-hd' } },
        { label: '🏞️ AI Background Studio', actionType: 'switch_tab', tab: 'bgchanger' },
      ],
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [inputMessage, setInputMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  if (!isOpen) return null;

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputMessage).trim();
    if (!query || loading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputMessage('');
    setLoading(true);

    try {
      const res = await fetch('/api/gemini/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          currentTab,
          hasImage,
        }),
      });

      const data = await res.json();
      if (data.success) {
        const assistantMsg: ChatMessage = {
          id: `asst-${Date.now()}`,
          sender: 'assistant',
          text: data.replyText,
          actions: data.suggestedActions,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, assistantMsg]);
      } else {
        throw new Error(data.error || 'Failed to connect to AI');
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          sender: 'assistant',
          text: `⚠️ **AI Assistant Error**: ${err.message || 'Unable to reach AI server.'}. You can still navigate using the tabs on the right panel!`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleActionClick = (action: AssistantAction) => {
    onPerformAssistantAction(action);
  };

  return (
    <div className="fixed inset-0 z-50 bg-neutral-950/80 backdrop-blur-md flex justify-end transition-all animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-neutral-900 border-l border-neutral-800 h-full flex flex-col shadow-2xl relative text-neutral-100">
        
        {/* Header */}
        <div className="p-4 border-b border-neutral-800/80 bg-neutral-950/80 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-emerald-500 to-emerald-700 p-0.5 flex items-center justify-center text-neutral-950 shadow-md shadow-emerald-500/20">
              <Bot className="w-5 h-5 text-neutral-950" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-bold text-neutral-100">AI Studio Assistant</h3>
                <span className="px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-extrabold uppercase border border-emerald-500/30">
                  Live Gemini
                </span>
              </div>
              <p className="text-[11px] text-neutral-400">Natural Language Photo Editor &amp; Guide</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-neutral-800 text-neutral-400 hover:text-white hover:bg-neutral-700 transition-colors cursor-pointer"
            title="Close Assistant"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Suggestion Pills */}
        <div className="p-3 border-b border-neutral-800/60 bg-neutral-950/40 overflow-x-auto no-scrollbar shrink-0">
          <div className="flex items-center gap-1.5 min-w-max">
            {INITIAL_PROMPTS.map((p, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(p.query)}
                disabled={loading}
                className="px-2.5 py-1 rounded-full bg-neutral-800/80 hover:bg-emerald-500/20 hover:border-emerald-500/40 border border-neutral-700/60 text-[11px] text-neutral-300 transition-all cursor-pointer whitespace-nowrap active:scale-95 disabled:opacity-50"
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'} space-y-1.5`}
            >
              <div
                className={`max-w-[88%] p-3.5 rounded-2xl text-xs leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-emerald-500 text-neutral-950 font-medium rounded-tr-none shadow-md'
                    : 'bg-neutral-800/90 border border-neutral-700/60 text-neutral-200 rounded-tl-none shadow-sm'
                }`}
              >
                <div className="whitespace-pre-wrap font-sans space-y-2">
                  {msg.text.split('\n\n').map((paragraph, pIdx) => (
                    <p key={pIdx}>
                      {paragraph.split('**').map((part, bIdx) =>
                        bIdx % 2 === 1 ? <strong key={bIdx} className="font-bold text-white">{part}</strong> : part
                      )}
                    </p>
                  ))}
                </div>

                {/* Interactive Action Shortcuts */}
                {msg.actions && msg.actions.length > 0 && (
                  <div className="mt-3 pt-2.5 border-t border-neutral-700/50 space-y-1.5">
                    <p className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">
                      Recommended Tool Actions:
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {msg.actions.map((act, actIdx) => (
                        <button
                          key={actIdx}
                          onClick={() => handleActionClick(act)}
                          className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500/20 to-emerald-600/20 hover:from-emerald-500 hover:to-emerald-600 border border-emerald-500/40 text-emerald-300 hover:text-neutral-950 font-bold text-[11px] flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
                        >
                          <Zap className="w-3 h-3 text-emerald-400 hover:text-neutral-950" />
                          <span>{act.label}</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <span className="text-[10px] text-neutral-500 px-1">{msg.timestamp}</span>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2 p-3 rounded-2xl bg-neutral-800/60 border border-neutral-700/40 text-neutral-400 text-xs w-fit animate-pulse">
              <Bot className="w-4 h-4 text-emerald-400 animate-spin" />
              <span>Gemini AI is analyzing your request...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="p-3 border-t border-neutral-800/80 bg-neutral-950/90 shrink-0">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Ask anything (e.g. 'Make my DP professional', 'Add Pakistan flag')..."
              disabled={loading}
              className="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-emerald-500/60 transition-all"
            />
            <button
              type="submit"
              disabled={!inputMessage.trim() || loading}
              className="p-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-neutral-950 disabled:opacity-40 transition-all cursor-pointer active:scale-95 shadow-md shadow-emerald-500/20"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>

      </div>
    </div>
  );
};
