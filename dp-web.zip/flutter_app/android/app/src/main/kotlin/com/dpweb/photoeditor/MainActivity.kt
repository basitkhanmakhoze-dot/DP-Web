package com.dpweb.photoeditor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
