import 'package:flutter/material.dart';

class ImageAdjustments {
  double brightness;
  double contrast;
  double saturation;
  double sharpen;
  double warmth;
  double skinGlow;
  double vibrance;

  ImageAdjustments({
    this.brightness = 0,
    this.contrast = 0,
    this.saturation = 0,
    this.sharpen = 0,
    this.warmth = 0,
    this.skinGlow = 0,
    this.vibrance = 0,
  });

  void reset() {
    brightness = 0;
    contrast = 0;
    saturation = 0;
    sharpen = 0;
    warmth = 0;
    skinGlow = 0;
    vibrance = 0;
  }
}

class PresetTemplate {
  final String id;
  final String name;
  final String description;
  final Color primaryColor;
  final String category;

  PresetTemplate({
    required this.id,
    required this.name,
    required this.description,
    required this.primaryColor,
    required this.category,
  });
}

class PresetFrame {
  final String id;
  final String name;
  final Color borderStartColor;
  final Color borderEndColor;
  final double borderWidth;

  PresetFrame({
    required this.id,
    required this.name,
    required this.borderStartColor,
    required this.borderEndColor,
    this.borderWidth = 8.0,
  });
}

class PresetBadge {
  final String id;
  final String name;
  final IconData icon;
  final Color color;

  PresetBadge({
    required this.id,
    required this.name,
    required this.icon,
    required this.color,
  });
}
