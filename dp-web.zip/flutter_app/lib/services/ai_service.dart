import 'dart:convert';
import 'package:http/http.dart' as http;

class AiAssistantResponse {
  final String replyText;
  final List<Map<String, dynamic>> suggestedActions;

  AiAssistantResponse({
    required this.replyText,
    required this.suggestedActions,
  });

  factory AiAssistantResponse.fromJson(Map<String, dynamic> json) {
    return AiAssistantResponse(
      replyText: json['replyText'] ?? 'I can help you enhance your profile picture!',
      suggestedActions: List<Map<String, dynamic>>.from(json['suggestedActions'] ?? []),
    );
  }
}

class AiService {
  static const String baseUrl = 'https://ais-dev-yyxx2bhpquamxmacajy7pd-412630428646.asia-east1.run.app';

  static Future<AiAssistantResponse> queryAssistant({
    required String message,
    required String currentTab,
    required bool hasImage,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/gemini/assistant'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'message': message,
          'currentTab': currentTab,
          'hasImage': hasImage,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          return AiAssistantResponse.fromJson(data);
        }
      }
      return AiAssistantResponse(
        replyText: "I'm ready to help! You can switch tabs below to enhance your photo, change background, or add frames.",
        suggestedActions: [
          {'label': 'Open AI Backgrounds', 'actionType': 'switch_tab', 'tab': 'bgchanger'},
          {'label': 'Enhance Photo Quality', 'actionType': 'switch_tab', 'tab': 'enhance'},
        ],
      );
    } catch (e) {
      return AiAssistantResponse(
        replyText: "You can ask me questions or use the tool tabs below to edit your photo.",
        suggestedActions: [
          {'label': 'Open AI Enhancer', 'actionType': 'switch_tab', 'tab': 'enhance'},
        ],
      );
    }
  }
}
