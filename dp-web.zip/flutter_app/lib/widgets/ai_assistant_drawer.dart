import 'package:flutter/material.dart';
import '../services/ai_service.dart';

class AiAssistantDrawer extends StatefulWidget {
  final String currentTab;
  final bool hasImage;
  final Function(Map<String, dynamic> action) onPerformAction;

  const AiAssistantDrawer({
    super.key,
    required this.currentTab,
    required this.hasImage,
    required this.onPerformAction,
  });

  @override
  State<AiAssistantDrawer> createState() => _AiAssistantDrawerState();
}

class _AiAssistantDrawerState extends State<AiAssistantDrawer> {
  final TextEditingController _controller = TextEditingController();
  final List<Map<String, dynamic>> _messages = [
    {
      'sender': 'assistant',
      'text': "👋 **Hello! I'm your DP Web AI Studio Assistant.**\n\nAsk me anything or tap a shortcut below to automatically edit your photo, change background to mountains, add Pakistan flag, sharpen facial details, or add verified ticks!",
      'actions': [
        {'label': '💼 Professional LinkedIn DP', 'actionType': 'switch_tab', 'tab': 'templates'},
        {'label': '🇵🇰 Pakistan Flag DP', 'actionType': 'apply_template', 'payload': {'templateId': 'pakistan-patriot'}},
        {'label': '✨ Auto AI HD Enhance', 'actionType': 'apply_preset', 'payload': {'preset': 'auto-hd'}},
        {'label': '🏞️ AI Background Studio', 'actionType': 'switch_tab', 'tab': 'bgchanger'},
      ]
    }
  ];
  bool _isLoading = false;

  final List<String> _quickPrompts = [
    '🇵🇰 Make Pakistan Flag DP',
    '💼 Make photo professional',
    '🏔️ Background to mountains',
    '✨ Sharpen & improve face',
    '🟢 Add WhatsApp Green Ring',
    '🕌 Islamic Mosque backdrop',
  ];

  void _sendMessage(String query) async {
    if (query.trim().isEmpty || _isLoading) return;

    setState(() {
      _messages.add({'sender': 'user', 'text': query});
      _isLoading = true;
    });
    _controller.clear();

    final response = await AiService.queryAssistant(
      message: query,
      currentTab: widget.currentTab,
      hasImage: widget.hasImage,
    );

    setState(() {
      _isLoading = false;
      _messages.add({
        'sender': 'assistant',
        'text': response.replyText,
        'actions': response.suggestedActions,
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: const Color(0xFF121212),
      child: SafeArea(
        child: Column(
          children: [
            // Drawer Header
            Container(
              padding: const EdgeInsets.all(16),
              decoration: const BoxDecoration(
                color: Color(0xFF1A1A1A),
                border: Border(bottom: BorderSide(color: Color(0xFF2A2A2A))),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: const Color(0xFF10B981).withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.auto_awesome, color: Color(0xFF10B981), size: 20),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'AI Studio Assistant',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                        ),
                        Text(
                          'Gemini 3.6 Natural Language Guide',
                          style: TextStyle(color: Colors.grey, fontSize: 11),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.grey),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),

            // Quick Prompt Chips
            SizedBox(
              height: 48,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                itemCount: _quickPrompts.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ActionChip(
                      backgroundColor: const Color(0xFF262626),
                      side: const BorderSide(color: Color(0xFF333333)),
                      label: Text(
                        _quickPrompts[index],
                        style: const TextStyle(color: Colors.white, fontSize: 11),
                      ),
                      onPressed: () => _sendMessage(_quickPrompts[index]),
                    ),
                  );
                },
              ),
            ),

            // Chat Messages List
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: _messages.length,
                itemBuilder: (context, index) {
                  final msg = _messages[index];
                  final isUser = msg['sender'] == 'user';
                  final actions = msg['actions'] as List<dynamic>?;

                  return Align(
                    alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: isUser ? const Color(0xFF10B981) : const Color(0xFF222222),
                        borderRadius: BorderRadius.circular(16),
                        border: isUser ? null : Border.all(color: const Color(0xFF333333)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            msg['text'] ?? '',
                            style: TextStyle(
                              color: isUser ? Colors.black : Colors.white,
                              fontSize: 13,
                              height: 1.4,
                            ),
                          ),
                          if (actions != null && actions.isNotEmpty) ...[
                            const SizedBox(height: 10),
                            Wrap(
                              spacing: 6,
                              runSpacing: 6,
                              children: actions.map((act) {
                                return ElevatedButton.icon(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFF10B981).withOpacity(0.2),
                                    foregroundColor: const Color(0xFF10B981),
                                    side: const BorderSide(color: Color(0xFF10B981)),
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                    minimumSize: Size.zero,
                                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                  ),
                                  icon: const Icon(Icons.bolt, size: 14),
                                  label: Text(
                                    act['label'] ?? 'Apply',
                                    style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
                                  ),
                                  onPressed: () {
                                    widget.onPerformAction(Map<String, dynamic>.from(act));
                                    Navigator.pop(context);
                                  },
                                );
                              }).toList(),
                            ),
                          ]
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),

            if (_isLoading)
              const Padding(
                padding: EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF10B981))),
                    SizedBox(width: 10),
                    Text('Gemini AI thinking...', style: TextStyle(color: Colors.grey, fontSize: 12)),
                  ],
                ),
              ),

            // Text Input Field
            Container(
              padding: const EdgeInsets.all(12),
              color: const Color(0xFF181818),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      style: const TextStyle(color: Colors.white, fontSize: 13),
                      decoration: const InputDecoration(
                        hintText: 'Ask AI assistant...',
                        hintStyle: TextStyle(color: Colors.grey, fontSize: 12),
                        border: InputBorder.none,
                      ),
                      onSubmitted: _sendMessage,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.send, color: Color(0xFF10B981)),
                    onPressed: () => _sendMessage(_controller.text),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
