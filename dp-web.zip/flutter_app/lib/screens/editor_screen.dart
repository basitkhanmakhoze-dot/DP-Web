import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/editor_models.dart';
import '../widgets/ai_assistant_drawer.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  String _activeTab = 'templates';
  XFile? _selectedImage;
  bool _isAiProcessing = false;
  final ImageAdjustments _adjustments = ImageAdjustments();

  PresetFrame? _selectedFrame;
  PresetBadge? _selectedBadge;
  String _backgroundStyle = 'default';

  final ImagePicker _picker = ImagePicker();

  final List<PresetTemplate> _templates = [
    PresetTemplate(id: 'whatsapp-pro', name: 'WhatsApp Verified', description: 'Emerald Green Ring + Verified Tick', primaryColor: const Color(0xFF10B981), category: 'Social'),
    PresetTemplate(id: 'linkedin-pro', name: 'LinkedIn Executive', description: 'Navy Executive + Open to Work Badge', primaryColor: const Color(0xFF1E3A8A), category: 'Professional'),
    PresetTemplate(id: 'pakistan-patriot', name: 'Pakistan Patriot', description: 'Emerald Flag Crescent + Gold Ring', primaryColor: const Color(0xFF065F46), category: 'National'),
    PresetTemplate(id: 'islamic-gold', name: 'Islamic Gold', description: 'Gold Ornamental Ring + Crescent Star', primaryColor: const Color(0xFFD97706), category: 'Islamic'),
    PresetTemplate(id: 'cyber-neon', name: 'Cyberpunk Neon', description: 'Glowing Neon Ring + Tech Badge', primaryColor: const Color(0xFF8B5CF6), category: 'Creative'),
  ];

  final List<PresetFrame> _frames = [
    PresetFrame(id: 'emerald-ring', name: 'WhatsApp Green Ring', borderStartColor: const Color(0xFF10B981), borderEndColor: const Color(0xFF059669)),
    PresetFrame(id: 'gold-ring', name: 'Gold Luxury Ring', borderStartColor: const Color(0xFFF59E0B), borderEndColor: const Color(0xFFD97706)),
    PresetFrame(id: 'neon-ring', name: 'Neon Pulse Ring', borderStartColor: const Color(0xFF8B5CF6), borderEndColor: const Color(0xFFEC4899)),
    PresetFrame(id: 'royal-blue', name: 'Royal Blue Ring', borderStartColor: const Color(0xFF2563EB), borderEndColor: const Color(0xFF1D4ED8)),
  ];

  final List<PresetBadge> _badges = [
    PresetBadge(id: 'verified', name: 'Verified Blue Tick', icon: Icons.verified, color: Colors.blue),
    PresetBadge(id: 'open-work', name: 'Open To Work', icon: Icons.work, color: Colors.green),
    PresetBadge(id: 'pro', name: 'PRO Creator', icon: Icons.star, color: Colors.amber),
    PresetBadge(id: 'vip', name: 'VIP Crown', icon: Icons.workspace_premium, color: Colors.purple),
  ];

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? image = await _picker.pickImage(source: source);
      if (image != null) {
        setState(() {
          _selectedImage = image;
        });
      }
    } catch (e) {
      debugPrint('Image pick error: $e');
    }
  }

  void _performAssistantAction(Map<String, dynamic> action) {
    setState(() {
      if (action['tab'] != null) {
        _activeTab = action['tab'];
      }
      if (action['actionType'] == 'apply_preset') {
        _adjustments.sharpen = 45;
        _adjustments.skinGlow = 20;
        _adjustments.brightness = 10;
        _activeTab = 'enhance';
      }
      if (action['actionType'] == 'apply_template') {
        _selectedFrame = _frames.first;
        _selectedBadge = _badges.first;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: const Color(0xFF10B981).withOpacity(0.2),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.camera_outlined, color: Color(0xFF10B981), size: 18),
            ),
            const SizedBox(width: 8),
            const Text('DP Web AI Studio', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_a_photo_outlined),
            onPressed: () => _showImageSourceDialog(),
            tooltip: 'Upload Photo',
          ),
          IconButton(
            icon: const Icon(Icons.share_outlined),
            onPressed: () => _exportPhoto(),
            tooltip: 'Export 1080x1080 HD',
          ),
        ],
      ),
      endDrawer: AiAssistantDrawer(
        currentTab: _activeTab,
        hasImage: _selectedImage != null,
        onPerformAction: _performAssistantAction,
      ),
      body: Column(
        children: [
          // 1080x1080 Interactive Preview Canvas Area
          Expanded(
            flex: 5,
            child: Container(
              color: const Color(0xFF0F0F0F),
              child: Center(
                child: AspectRatio(
                  aspectRatio: 1.0,
                  child: Container(
                    margin: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: const Color(0xFF181818),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(
                        color: _selectedFrame != null ? _selectedFrame!.borderStartColor : const Color(0xFF282828),
                        width: _selectedFrame != null ? 6.0 : 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: (_selectedFrame?.borderStartColor ?? Colors.black).withOpacity(0.25),
                          blurRadius: 20,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        // Image Display
                        if (_selectedImage != null)
                          ClipRRect(
                            borderRadius: BorderRadius.circular(18),
                            child: Image.file(
                              File(_selectedImage!.path),
                              fit: BoxFit.cover,
                              width: double.infinity,
                              height: double.infinity,
                            ),
                          )
                        else
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.add_photo_alternate_outlined, size: 56, color: Colors.grey[700]),
                              const SizedBox(height: 12),
                              Text('Tap to upload photo', style: TextStyle(color: Colors.grey[500], fontSize: 13, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 4),
                              Text('1080×1080 HD Profile Picture Maker', style: TextStyle(color: Colors.grey[700], fontSize: 11)),
                              const SizedBox(height: 16),
                              ElevatedButton.icon(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFF10B981),
                                  foregroundColor: Colors.black,
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                ),
                                icon: const Icon(Icons.upload_file, size: 16),
                                label: const Text('Select Photo', style: TextStyle(fontWeight: FontWeight.bold)),
                                onPressed: () => _showImageSourceDialog(),
                              ),
                            ],
                          ),

                        // Badge Overlay
                        if (_selectedBadge != null)
                          Positioned(
                            bottom: 12,
                            right: 12,
                            child: Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: Colors.black80,
                                shape: BoxShape.circle,
                                border: Border.all(color: _selectedBadge!.color, width: 2),
                              ),
                              child: Icon(_selectedBadge!.icon, color: _selectedBadge!.color, size: 22),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

          // Editing Tool Tabs Bar
          Container(
            height: 48,
            color: const Color(0xFF141414),
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 8),
              children: [
                _buildToolTab('templates', 'Templates', Icons.auto_awesome),
                _buildToolTab('enhance', 'AI Enhance', Icons.auto_fix_high),
                _buildToolTab('bgchanger', 'AI Background', Icons.wallpaper),
                _buildToolTab('frames', 'Frames', Icons.crop_free),
                _buildToolTab('badges', 'Badges', Icons.verified),
              ],
            ),
          ),

          // Active Tool Controls Panel
          Expanded(
            flex: 4,
            child: Container(
              color: const Color(0xFF1A1A1A),
              padding: const EdgeInsets.all(16),
              child: _buildActiveToolPanel(),
            ),
          ),
        ],
      ),

      // Floating AI Assistant Button
      floatingActionButton: Builder(
        builder: (context) => FloatingActionButton.extended(
          backgroundColor: const Color(0xFF10B981),
          foregroundColor: Colors.black,
          icon: const Icon(Icons.sparkles),
          label: const Text('AI Assistant', style: TextStyle(fontWeight: FontWeight.bold)),
          onPressed: () => Scaffold.of(context).openEndDrawer(),
        ),
      ),
    );
  }

  Widget _buildToolTab(String id, String label, IconData icon) {
    final isActive = _activeTab == id;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
      child: ChoiceChip(
        selected: isActive,
        backgroundColor: const Color(0xFF222222),
        selectedColor: const Color(0xFF10B981),
        labelStyle: TextStyle(
          color: isActive ? Colors.black : Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 12,
        ),
        avatar: Icon(icon, size: 16, color: isActive ? Colors.black : const Color(0xFF10B981)),
        label: Text(label),
        onSelected: (_) => setState(() => _activeTab = id),
      ),
    );
  }

  Widget _buildActiveToolPanel() {
    switch (_activeTab) {
      case 'enhance':
        return ListView(
          children: [
            const Text('AI Photo Enhancer Controls', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
            const SizedBox(height: 12),
            _buildSlider('Sharpen & Facial Detail', _adjustments.sharpen, 0, 100, (v) => setState(() => _adjustments.sharpen = v)),
            _buildSlider('Skin Glow', _adjustments.skinGlow, 0, 100, (v) => setState(() => _adjustments.skinGlow = v)),
            _buildSlider('Brightness', _adjustments.brightness, -50, 50, (v) => setState(() => _adjustments.brightness = v)),
            _buildSlider('Contrast', _adjustments.contrast, -50, 50, (v) => setState(() => _adjustments.contrast = v)),
          ],
        );

      case 'frames':
        return GridView.builder(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 2.8, crossAxisSpacing: 8, mainAxisSpacing: 8),
          itemCount: _frames.length,
          itemBuilder: (context, idx) {
            final f = _frames[idx];
            final isSelected = _selectedFrame?.id == f.id;
            return InkWell(
              onTap: () => setState(() => _selectedFrame = isSelected ? null : f),
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFF242424),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: isSelected ? const Color(0xFF10B981) : Colors.transparent, width: 2),
                ),
                child: Row(
                  children: [
                    CircleAvatar(backgroundColor: f.borderStartColor, radius: 12),
                    const SizedBox(width: 8),
                    Expanded(child: Text(f.name, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold))),
                  ],
                ),
              ),
            );
          },
        );

      case 'badges':
        return GridView.builder(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 2.8, crossAxisSpacing: 8, mainAxisSpacing: 8),
          itemCount: _badges.length,
          itemBuilder: (context, idx) {
            final b = _badges[idx];
            final isSelected = _selectedBadge?.id == b.id;
            return InkWell(
              onTap: () => setState(() => _selectedBadge = isSelected ? null : b),
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFF242424),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: isSelected ? const Color(0xFF10B981) : Colors.transparent, width: 2),
                ),
                child: Row(
                  children: [
                    Icon(b.icon, color: b.color, size: 20),
                    const SizedBox(width: 8),
                    Expanded(child: Text(b.name, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold))),
                  ],
                ),
              ),
            );
          },
        );

      default:
        return ListView.builder(
          itemCount: _templates.length,
          itemBuilder: (context, idx) {
            final t = _templates[idx];
            return Card(
              color: const Color(0xFF222222),
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: CircleAvatar(backgroundColor: t.primaryColor, child: const Icon(Icons.star, color: Colors.white, size: 16)),
                title: Text(t.name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                subtitle: Text(t.description, style: const TextStyle(color: Colors.grey, fontSize: 11)),
                trailing: ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF10B981), foregroundColor: Colors.black),
                  child: const Text('Apply', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                  onPressed: () {
                    setState(() {
                      _selectedFrame = _frames.first;
                      _selectedBadge = _badges.first;
                    });
                  },
                ),
              ),
            );
          },
        );
    }
  }

  Widget _buildSlider(String label, double value, double min, double max, ValueChanged<double> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.between,
          children: [
            Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
            Text(value.toStringAsFixed(0), style: const TextStyle(color: Color(0xFF10B981), fontSize: 12, fontWeight: FontWeight.bold)),
          ],
        ),
        Slider(
          value: value,
          min: min,
          max: max,
          activeColor: const Color(0xFF10B981),
          inactiveColor: const Color(0xFF333333),
          onChanged: onChanged,
        ),
      ],
    );
  }

  void _showImageSourceDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF181818),
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Color(0xFF10B981)),
              title: const Text('Take Photo with Camera', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.camera);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Color(0xFF10B981)),
              title: const Text('Choose from Gallery', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.gallery);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _exportPhoto() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('🎉 Photo ready! Exported in 1080×1080 HD Quality.'),
        backgroundColor: Color(0xFF10B981),
      ),
    );
  }
}
